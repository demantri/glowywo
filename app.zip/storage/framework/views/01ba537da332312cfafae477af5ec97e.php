<!DOCTYPE html>
<html lang="en">
<!-- [Head] start -->

<head>
    <title>Login | Glowy Wedding &amp; Event Organizer</title>
    <!-- [Meta] -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description"
        content="Mantis is made using Bootstrap 5 design framework. Download the free admin template & use it for your project.">
    <meta name="keywords"
        content="Mantis, Dashboard UI Kit, Bootstrap 5, Admin Template, Admin Dashboard, CRM, CMS, Bootstrap Admin Template">
    <meta name="author" content="CodedThemes">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- [Favicon] icon -->
    <link rel="icon" href="<?php echo e(asset('template/assets/images/favicon.svg')); ?>" type="image/x-icon">
    <!-- [Google Font] Family -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@300;400;500;600;700&display=swap"
        id="main-font-link">
    <!-- [Tabler Icons] https://tablericons.com -->
    <link rel="stylesheet" href="<?php echo e(asset('template/assets/fonts/tabler-icons.min.css')); ?>">
    <!-- [Feather Icons] https://feathericons.com -->
    <link rel="stylesheet" href="<?php echo e(asset('template/assets/fonts/feather.css')); ?>">
    <!-- [Font Awesome Icons] https://fontawesome.com/icons -->
    <link rel="stylesheet" href="<?php echo e(asset('template/assets/fonts/fontawesome.css')); ?>">
    <!-- [Material Icons] https://fonts.google.com/icons -->
    <link rel="stylesheet" href="<?php echo e(asset('template/assets/fonts/material.css')); ?>">
    <!-- [Template CSS Files] -->
    <link rel="stylesheet" href="<?php echo e(asset('template/assets/css/style.css')); ?>" id="main-style-link">
    <link rel="stylesheet" href="<?php echo e(asset('template/assets/css/style-preset.css')); ?>">

</head>
<!-- [Head] end -->
<!-- [Body] Start -->

<body>
    <!-- [ Pre-loader ] start -->
    <div class="loader-bg">
        <div class="loader-track">
            <div class="loader-fill"></div>
        </div>
    </div>
    <!-- [ Pre-loader ] End -->

    <div class="auth-main">
        <div class="auth-wrapper v3">
            <div class="auth-form">
                <div class="auth-header">
                    <a href="#"><img src="<?php echo e(asset('template/img/glowy-logo.png')); ?>" alt="img"></a>
                    
                </div>
                <div class="card my-5">
                    <div class="card-body">

                        <div class="d-flex justify-content-between align-items-end mb-4">
                            <h3 class="mb-0"><b>Login</b></h3>
                        </div>

                        <form id="myForm">
                            <div class="form-group mb-3">
                                <label class="form-label">Email Address</label>
                                <input type="email" id="email" name="email" class="form-control"
                                    placeholder="Email Address">
                                <small id="error_email" class="text-danger"></small>
                            </div>

                            <div class="form-group mb-3">
                                <label class="form-label">Password</label>
                                <input type="password" id="password" name="password" class="form-control"
                                    placeholder="Password">
                                <small id="error_password" class="text-danger"></small>
                            </div>

                            <div class="d-grid mt-4">
                                <button type="submit" id="btnLogin" class="btn btn-primary">Login</button>
                            </div>
                        </form>

                    </div>
                </div>

                <div class="auth-footer row">
                    <!-- <div class=""> -->
                    <div class="col my-1">
                        <p class="m-0">Copyright © <a href="#">Glowy</a></p>
                    </div>
                    
                    <!-- </div> -->
                </div>
            </div>
        </div>
    </div>
    <!-- [ Main Content ] end -->
    <!-- Required Js -->
    <script src="<?php echo e(asset('template/assets/js/plugins/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/assets/js/plugins/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/assets/js/plugins/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/assets/js/fonts/custom-font.js')); ?>"></script>
    <script src="<?php echo e(asset('template/assets/js/pcoded.js')); ?>"></script>
    <script src="<?php echo e(asset('template/assets/js/plugins/feather.min.js')); ?>"></script>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        $(document).ready(function() {

            $("#myForm").submit(function(e) {
                e.preventDefault();

                // Bersihkan error dulu
                $("#error_email").text("");
                $("#error_password").text("");

                $.ajax({
                    url: "<?php echo e(route('login.process')); ?>",
                    method: "POST",
                    data: {
                        email: $("#email").val(),
                        password: $("#password").val(),
                        _token: "<?php echo e(csrf_token()); ?>"
                    },

                    success: function(res) {
                        Swal.fire({
                            icon: "success",
                            title: "Login Berhasil",
                            text: 'Mengalihkan ke dashboard...',
                            showConfirmButton: false,
                            timer: 1200
                        });

                        setTimeout(() => {
                            window.location.href = res.redirect;
                        }, 1300);
                    },

                    error: function(err) {

                        // Jika error validasi
                        if (err.status === 422) {
                            let e = err.responseJSON.errors;

                            if (e.email) $("#error_email").text(e.email);
                            if (e.password) $("#error_password").text(e.password);

                            return;
                        }

                        // Jika email/password salah (401)
                        Swal.fire({
                            icon: "error",
                            title: "Login gagal",
                            text: err.responseJSON.message
                        });
                    }
                });
            });

        });
    </script>

    <script>
        layout_change('light');
    </script>




    <script>
        change_box_container('false');
    </script>



    <script>
        layout_rtl_change('false');
    </script>


    <script>
        preset_change("preset-1");
    </script>


    <script>
        font_change("Public-Sans");
    </script>



</body>
<!-- [Body] end -->

</html>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>