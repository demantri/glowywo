<section id="services" class="services section">
    <div class="container section-title" data-aos="fade-up">
        <span class="subtitle"><?php echo e($headerLayanan->title_tag ?? null); ?></span>
        <h2><?php echo e($headerLayanan->main_title ?? null); ?></h2>
        <p>
            <?php echo e($headerLayanan->intro_text ?? null); ?>

        </p>
    </div>

    <div class="container" data-aos="fade-up" data-aos-delay="100">
        <div class="row gy-5">
            <?php for($i = 0; $i < count($layanan); $i++): ?>
            <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
                <div class="service-item">
                    <div class="service-icon">
                        <i class="<?php echo e($layanan[$i]->service_icon); ?>"></i>
                    </div>
                    <h3><?php echo e($layanan[$i]->service_title); ?></h3>
                    <p>
                        <?php echo e($layanan[$i]->service_desc); ?>

                    </p>
                    <a href="service-details.html" class="service-link">
                        <?php echo e($layanan[$i]->service_link_text); ?> <i class="bi bi-arrow-right"></i>
                    </a>
                </div>
            </div>
            <?php endfor; ?>
        </div>
    </div>
</section>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/website/services.blade.php ENDPATH**/ ?>