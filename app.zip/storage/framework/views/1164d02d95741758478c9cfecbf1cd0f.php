<script>
    $(function() {

        $("#userTable").DataTable();

        $("#btnAdd").click(function() {
            $("#addModal").modal('show');
        });

        // =======================
        // ADD USER
        // =======================
        $("#btnSave").click(function() {
            let formData = new FormData();
            formData.append("name", $("#add_name").val());
            formData.append("username", $("#add_username").val());
            formData.append("email", $("#add_email").val());
            formData.append("password", $("#add_password").val());
            formData.append("role_id", $("#add_role").val());
            formData.append("photo", $("#add_photo")[0].files[0]);
            formData.append("social_media", $("#add_social").val());
            formData.append("_token", "<?php echo e(csrf_token()); ?>");

            $.ajax({
                url: "<?php echo e(route('users.store')); ?>",
                method: "POST",
                data: formData,
                contentType: false,
                processData: false,

                success: function() {
                    toastr.success("User berhasil ditambahkan!");
                    setTimeout(() => location.reload(), 800);
                },

                error: function(err) {
                    toastr.error("Gagal menambahkan user.");
                }
            });
        });

        // ============================
        // SHOW EDIT MODAL
        // ============================
        $(".btn-edit").click(function() {
            let id = $(this).data("id");
            let name = $(this).data("name");
            let username = $(this).data("username");
            let email = $(this).data("email");
            let role = $(this).data("role");
            let social = $(this).data("social");

            $("#edit_id").val(id);
            $("#edit_name").val(name);
            $("#edit_username").val(username);
            $("#edit_email").val(email);
            $("#edit_role").val(role);
            $("#edit_social").val(social);
            $("#edit_password").val("");

            $("#editModal").modal("show");
        });


        // ============================
        // UPDATE USER (AJAX)
        // ============================
        $("#btnUpdate").click(function() {

            let id = $("#edit_id").val();
            $("#edit_error_name").text("");

            let formData = new FormData();
            formData.append("name", $("#edit_name").val());
            formData.append("username", $("#edit_username").val());
            formData.append("email", $("#edit_email").val());
            // formData.append("password", $("#edit_password").val());
            formData.append("role_id", $("#edit_role").val());
            // formData.append("social_media", $("#edit_social").val());
            formData.append("_token", "<?php echo e(csrf_token()); ?>");
            formData.append("_method", "PUT");

            // if ($("#edit_photo")[0].files[0]) {
            //     formData.append("photo", $("#edit_photo")[0].files[0]);
            // }

            $.ajax({
                url: "/admin/users/" + id,
                method: "POST",
                data: formData,
                contentType: false,
                processData: false,

                success: function() {
                    Swal.fire({
                        icon: "success",
                        title: "Berhasil!",
                        text: "Data user berhasil diperbarui",
                        timer: 1200,
                        showConfirmButton: false
                    });

                    setTimeout(() => {
                        location.reload();
                    }, 1200);
                },

                error: function(err) {
                    if (err.status === 422) {
                        $("#edit_error_name").text(err.responseJSON.errors.name);
                    } else {
                        toastr.error("Terjadi kesalahan.");
                    }
                }
            });
        });

        // =======================
        // DELETE USER
        // =======================
        $(".btn-delete").click(function() {

            let id = $(this).data("id");

            Swal.fire({
                title: "Yakin hapus?",
                text: "Data ini tidak bisa dikembalikan!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "Ya, hapus!",
                cancelButtonText: "Batal",
            }).then((res) => {
                if (res.isConfirmed) {

                    $.ajax({
                        url: "/admin/users/" + id,
                        method: "DELETE",
                        data: {
                            _token: "<?php echo e(csrf_token()); ?>"
                        },

                        success: function() {
                            toastr.success("User berhasil dihapus!");
                            setTimeout(() => location.reload(), 700);
                        }
                    });
                }
            });

        });

    });
</script>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/user/script.blade.php ENDPATH**/ ?>