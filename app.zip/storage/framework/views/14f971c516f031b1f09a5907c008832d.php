<section id="about" class="about section">

    <!-- Section Title -->
    <div class="container section-title" data-aos="fade-up">
        <span class="subtitle"><?php echo e($tentangKami->title_tag); ?></span>
        <h2><?php echo e($tentangKami->main_title); ?></h2>
        <p>
            <?php echo e($tentangKami->intro_text); ?>

        </p>
    </div><!-- End Section Title -->

    <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row align-items-center">
            <div class="col-lg-6" data-aos="fade-right" data-aos-delay="200">
                <div class="content">
                    <h2><?php echo e($tentangKami->body_headline); ?></h2>
                    <p class="lead">
                        <?php echo e($tentangKami->body_subheadline); ?>

                    </p>
                    <p>
                        <?php echo e($tentangKami->body_paragraf_1); ?>

                    </p>
                    <p>
                        <?php echo e($tentangKami->body_paragraf_2); ?>

                    </p>

                    <div class="stats-row">
                        <?php if(!is_null($tentangKami->award_desc1)): ?>
                        <div class="stat-item">
                            <div class="stat-number purecounter" data-purecounter-start="0" data-purecounter-end="<?php echo e($tentangKami->award_title1); ?>"
                                data-purecounter-duration="1"></div>
                            <div class="stat-label"><?php echo e($tentangKami->award_desc1); ?></div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if(!is_null($tentangKami->award_desc2)): ?>
                        <div class="stat-item">
                            <div class="stat-number purecounter" data-purecounter-start="0" data-purecounter-end="<?php echo e($tentangKami->award_title2); ?>"
                                data-purecounter-duration="1"></div>
                            <div class="stat-label"><?php echo e($tentangKami->award_desc2); ?></div>
                        </div>
                        <?php endif; ?>

                        <?php if(!is_null($tentangKami->award_desc3)): ?>
                        <div class="stat-item">
                            <div class="stat-number purecounter" data-purecounter-start="0" data-purecounter-end="<?php echo e($tentangKami->award_title3); ?>"
                                data-purecounter-duration="1"></div>
                            <div class="stat-label"><?php echo e($tentangKami->award_desc3); ?></div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="col-lg-6" data-aos="fade-left" data-aos-delay="300">
                <div class="image-wrapper">
                    <img src="<?php echo e(asset('storage/' . $tentangKami->image)); ?>" alt="About us" class="img-fluid">
                </div>
            </div>
        </div>

    </div>

</section>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/website/about.blade.php ENDPATH**/ ?>