<footer id="footer" class="footer dark-background">
    <div class="container footer-top">
        <div class="row gy-4">
            <div class="col-lg-5 col-md-12 footer-about">
                <a href="index.html" class="logo d-flex align-items-center">
                    <span class="sitename">Glowy</span>
                </a>
                <p>
                    <?php echo e($footer->company_desc); ?>

                </p>
                <div class="social-links d-flex mt-4">
                    <?php if(!is_null($footer->social_instagram)): ?>
                    <a target="_blank" href="https://instagram.com/<?php echo e($footer->social_instagram); ?>"><i class="bi bi-instagram"></i></a>
                    <?php endif; ?>

                    <?php if(!is_null($footer->social_facebook)): ?>
                    <a target="_blank" href="https://facebook.com/<?php echo e($footer->social_facebook); ?>"><i class="bi bi-facebook"></i></a>
                    <?php endif; ?>

                    <?php if(!is_null($footer->social_linkedin)): ?>
                    <a target="_blank" href="https://linkedin.com/in/<?php echo e($footer->social_linkedin); ?>"><i class="bi bi-linkedin"></i></a>
                    <?php endif; ?>
                    
                </div>
            </div>

            <div class="col-lg-2 col-6 footer-links">
                <h4>Link Cepat</h4>
                <ul>
                    <?php $__currentLoopData = $navItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e($item->nav_slug); ?>"><?php echo e($item->nav_label); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <div class="col-lg-2 col-6 footer-links">
                <h4>Layanan Kami</h4>
                <ul>
                    <?php $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="#services"><?php echo e($item->service_title); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <div class="col-lg-3 col-md-12 footer-contact text-center text-md-start">
                <h4>Hubungi Kami</h4>
                <p>
                    <?php echo e($profilePerusahaan->alamat_kantor); ?>

                </p>
                <p class="mt-4"><strong>Telepon:</strong> <span><?php echo e($profilePerusahaan->no_telp_kantor); ?></span></p>
                <p><strong>Email:</strong> <span><?php echo e($profilePerusahaan->email_kantor); ?></span></p>
            </div>

        </div>
    </div>

    <div class="container copyright text-center mt-4">
        <p>
            © <span>Copyright</span> <strong class="px-1 sitename"> <?php echo e($footer->copyright_year); ?> </strong> <span>Glowy.</span>
        </p>
    </div>
</footer>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/website/footer.blade.php ENDPATH**/ ?>