<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">Edit Profile Perusahaan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <input type="hidden" id="edit_profile_id">

                <div class="row">

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Nama Perusahaan</label>
                        <input type="text" id="edit_nama_perusahaan" class="form-control">
                        <small class="text-danger error-text" id="edit_error_nama_perusahaan"></small>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Alias Perusahaan</label>
                        <input type="text" id="edit_alias_perusahaan" class="form-control">
                        <small class="text-danger error-text" id="edit_error_alias_perusahaan"></small>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">No. Telp Kantor</label>
                        <input type="text" id="edit_no_telp" class="form-control">
                        <small class="text-danger error-text" id="edit_error_no_telp"></small>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">No. WhatsApp</label>
                        <input type="text" id="edit_no_wa" class="form-control">
                        <small class="text-danger error-text" id="edit_error_no_wa"></small>
                    </div>

                    <div class="col-md-12 mb-3">
                        <label class="form-label">Alamat Kantor</label>
                        <textarea id="edit_alamat" rows="3" class="form-control"></textarea>
                        <small class="text-danger error-text" id="edit_error_alamat"></small>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Email Kantor</label>
                        <input type="text" id="edit_email_kantor" class="form-control">
                        <small class="text-danger error-text" id="edit_error_email_kantor"></small>
                    </div>

                    <hr>

                    <!-- PREVIEW LOGO HEADER -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Logo Header (Sebelumnya)</label> <br>
                        <img id="preview_logo_header" src="" class="img-thumbnail mb-2"
                             style="width: 120px; height: 120px; object-fit: contain;">
                        <input type="file" id="edit_logo_header" class="form-control">
                    </div>

                    <!-- PREVIEW LOGO FOOTER -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Logo Footer (Sebelumnya)</label> <br>
                        <img id="preview_logo_footer" src="" class="img-thumbnail mb-2"
                             style="width: 120px; height: 120px; object-fit: contain;">
                        <input type="file" id="edit_logo_footer" class="form-control">
                    </div>

                </div>

            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button class="btn btn-primary" id="btnUpdate">Update</button>
            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/perusahaan/edit.blade.php ENDPATH**/ ?>