<script>
    $(function() {

        // SHOW ADD MODAL
        $("#btnAdd").click(function() {
            $("#addModal").modal("show");
        });

        // PREVIEW IMAGE - ADD
        $("#add_image").change(function() {
            let img = URL.createObjectURL(this.files[0]);
            $("#preview_add_image").attr("src", img).show();
        });

        // SAVE DATA
        $("#btnSave").click(function() {

            let formData = new FormData();
            formData.append("hero_headline", $("#add_hero_headline").val());
            formData.append("hero_subtext", $("#add_hero_subtext").val());
            formData.append("btn_primary_text", $("#add_btn_primary_text").val());
            formData.append("btn_secondary_text", $("#add_btn_secondary_text").val());

            for (let i = 1; i <= 3; i++) {
                formData.append(`stat_${i}_value`, $(`#add_stat_${i}_value`).val());
                formData.append(`stat_${i}_label`, $(`#add_stat_${i}_label`).val());
            }

            if ($("#add_image")[0].files[0]) {
                formData.append("image", $("#add_image")[0].files[0]);
            }

            formData.append("_token", "<?php echo e(csrf_token()); ?>");

            $.ajax({
                url: "<?php echo e(route('beranda.store')); ?>",
                method: "POST",
                data: formData,
                contentType: false,
                processData: false,

                success: function(res) {
                    $("#addModal").modal("hide");
                    $(".modal-backdrop").remove();
                    Swal.fire("Berhasil", res.message, "success").then(() => {
                        location.reload();
                    });
                },

                error: function() {
                    Swal.fire("Gagal", "Periksa kembali input Anda", "error");
                }
            });

        });

        // SHOW EDIT MODAL
        $(".btn-edit").click(function() {

            $("#edit_id").val($(this).data("id"));

            $("#edit_hero_headline").val($(this).data("hero_headline"));
            $("#edit_hero_subtext").val($(this).data("hero_subtext"));
            $("#edit_btn_primary_text").val($(this).data("btn_primary_text"));
            $("#edit_btn_secondary_text").val($(this).data("btn_secondary_text"));

            $("#edit_stat_1_value").val($(this).data("stat_1_value"));
            $("#edit_stat_1_label").val($(this).data("stat_1_label"));

            $("#edit_stat_2_value").val($(this).data("stat_2_value"));
            $("#edit_stat_2_label").val($(this).data("stat_2_label"));

            $("#edit_stat_3_value").val($(this).data("stat_3_value"));
            $("#edit_stat_3_label").val($(this).data("stat_3_label"));

            $("#editModal").modal("show");
        });

        // PREVIEW EDIT IMAGE
        $("#edit_image").change(function() {
            let img = URL.createObjectURL(this.files[0]);
            $("#preview_edit_image").attr("src", img).show();
        });

        // UPDATE DATA
        $("#btnUpdate").click(function() {

            let id = $("#edit_id").val();
            let formData = new FormData();

            formData.append("hero_headline", $("#edit_hero_headline").val());
            formData.append("hero_subtext", $("#edit_hero_subtext").val());
            formData.append("btn_primary_text", $("#edit_btn_primary_text").val());
            formData.append("btn_secondary_text", $("#edit_btn_secondary_text").val());

            for (let i = 1; i <= 3; i++) {
                formData.append(`stat_${i}_value`, $(`#edit_stat_${i}_value`).val());
                formData.append(`stat_${i}_label`, $(`#edit_stat_${i}_label`).val());
            }

            if ($("#edit_image")[0].files[0]) {
                formData.append("image", $("#edit_image")[0].files[0]);
            }

            formData.append("_token", "<?php echo e(csrf_token()); ?>");
            formData.append("_method", "PUT");

            $.ajax({
                url: "/admin/beranda/" + id,
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,

                success: function(res) {
                    $("#editModal").modal("hide");
                    $(".modal-backdrop").remove();
                    Swal.fire("Berhasil", res.message, "success").then(() => {
                        location.reload();
                    });
                },

                error: function() {
                    Swal.fire("Gagal", "Harap periksa input Anda", "error");
                }
            });
        });

        // DELETE DATA
        $(".btn-delete").click(function() {

            let id = $(this).data("id");

            Swal.fire({
                title: "Hapus data?",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "Ya, hapus",
                cancelButtonText: "Batal"
            }).then((result) => {

                if (result.isConfirmed) {

                    $.ajax({
                        url: "/admin/beranda/" + id,
                        method: "DELETE",
                        data: {
                            _token: "<?php echo e(csrf_token()); ?>"
                        },

                        success: function(res) {
                            Swal.fire("Berhasil", res.message, "success").then(
                                () => {
                                    location.reload();
                                });
                        }
                    });

                }
            });
        });

    });
</script>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/beranda/script.blade.php ENDPATH**/ ?>