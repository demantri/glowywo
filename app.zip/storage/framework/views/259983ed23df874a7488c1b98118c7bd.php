<script>
    $(function() {

        $("#table").DataTable();

        $("#btnAdd").click(function() {
            $("#addModal").modal('show');
        });

        $('#btnSave').on('click', function() {
            let service_icon = $('#add_service_icon').val();
            let service_title = $('#add_service_title').val();
            let service_desc = $('#add_service_desc').val();
            let service_link_text = $('#add_service_link_text').val();
            let service_order = $('#add_service_order').val();
            let flag_aktif = $('#add_flag_aktif').is(':checked') ? 1 : 0;

            // Reset error message
            $('#error_service_icon').text('');
            $('#error_service_title').text('');
            $('#error_service_desc').text('');
            $('#error_service_link_text').text('');
            $('#error_service_order').text('');

            $.ajax({
                url: "<?php echo e(route('layanan.store')); ?>", // Sesuaikan route Anda
                type: "POST",
                data: {
                    service_icon: service_icon,
                    service_title: service_title,
                    service_desc: service_desc,
                    service_link_text: service_link_text,
                    service_order: service_order,
                    flag_aktif: flag_aktif,
                    _token: "<?php echo e(csrf_token()); ?>"
                },
                success: function(res) {
                    $("#addModal").modal("hide");
                    $(".modal-backdrop").remove();

                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil',
                        text: res.message,
                        timer: 1000,
                        showConfirmButton: false
                    }).then(() => {
                        // Reload halaman
                        setTimeout(() => location.reload(), 200);
                    });
                },
                error: function(xhr) {
                    if (xhr.status === 422) {
                        let errors = xhr.responseJSON.errors;

                        if (errors.service_icon)
                            $('#error_service_icon').text(errors.service_icon[0]);

                        if (errors.service_title)
                            $('#error_service_title').text(errors.service_title[0]);

                        if (errors.service_desc)
                            $('#error_service_desc').text(errors.service_desc[0]);

                        if (errors.service_link_text)
                            $('#error_service_link_text').text(errors.service_link_text[0]);

                        if (errors.service_order)
                            $('#error_service_order').text(errors.service_order[0]);

                        Swal.fire({
                            icon: 'error',
                            title: 'Validasi gagal',
                            text: 'Periksa input form Anda.',
                            timer: 1200,
                            showConfirmButton: false
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Gagal',
                            text: 'Terjadi kesalahan server.',
                            timer: 1500,
                            showConfirmButton: false
                        });
                    }
                }
            });
        });

        $(".btn-edit").click(function() {

            $("#edit_service_id").val($(this).data("id"));
            $("#edit_service_icon").val($(this).data("icon"));
            $("#edit_service_title").val($(this).data("title"));
            $("#edit_service_desc").val($(this).data("desc"));
            $("#edit_service_link_text").val($(this).data("link"));
            $("#edit_service_order").val($(this).data("order"));

            // Set Flag Aktif
            if ($(this).data("aktif") == 1) {
                $("#edit_flag_aktif").prop("checked", true);
            } else {
                $("#edit_flag_aktif").prop("checked", false);
            }

            // Tampilkan modal edit
            $("#editModal").modal("show");
        });


        $("#btnUpdate").click(function() {
            let id = $("#edit_service_id").val();
            $.ajax({
                url: "/admin/layanan/" + id,
                method: "POST",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    _method: "PUT",
                    service_icon: $("#edit_service_icon").val(),
                    service_title: $("#edit_service_title").val(),
                    service_desc: $("#edit_service_desc").val(),
                    service_link_text: $("#edit_service_link_text").val(),
                    service_order: $("#edit_service_order").val(),
                    flag_aktif: $("#edit_flag_aktif").is(":checked") ? 1 : 0
                },
                success: function(res) {
                    $("#editModal").modal("hide");
                    $(".modal-backdrop").remove();

                    Swal.fire({
                        icon: "success",
                        title: "Berhasil!",
                        text: res.message,
                        timer: 1000,
                        showConfirmButton: false
                    }).then(() => {
                        setTimeout(() => location.reload(), 200);
                    });
                },
                error: function(xhr) {
                    let e = xhr.responseJSON.errors;

                    $("#edit_error_service_icon").text(e?.service_icon ?? "");
                    $("#edit_error_service_title").text(e?.service_title ?? "");
                    $("#edit_error_service_desc").text(e?.service_desc ?? "");
                    $("#edit_error_service_link_text").text(e?.service_link_text ?? "");
                    $("#edit_error_service_order").text(e?.service_order ?? "");

                    Swal.fire({
                        icon: "error",
                        title: "Validasi gagal",
                        text: "Periksa inputan anda.",
                        timer: 1500,
                        showConfirmButton: false
                    });
                }
            });
        });

        $(".btn-delete").click(function() {

            let id = $(this).data("id");

            Swal.fire({
                title: "Yakin hapus?",
                text: "Data ini tidak bisa dikembalikan!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "Ya, hapus!",
                cancelButtonText: "Batal",
            }).then((res) => {
                if (res.isConfirmed) {

                    $.ajax({
                        url: "/admin/layanan/" + id,
                        method: "DELETE",
                        data: {
                            _token: "<?php echo e(csrf_token()); ?>"
                        },

                        success: function() {
                            toastr.success("Data berhasil dihapus!");
                            setTimeout(() => location.reload(), 700);
                        }
                    });
                }
            });

        });

        $(document).on('change', '.toggle-aktif', function() {
            let id = $(this).data('id');
            let status = $(this).is(':checked') ? 1 : 0;

            $.ajax({
                url: "<?php echo e(route('layanan.toggleAktif')); ?>",
                type: "POST",
                data: {
                    id: id,
                    flag_aktif: status,
                    _token: "<?php echo e(csrf_token()); ?>"
                },
                success: function(res) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil',
                        text: res.message,
                        timer: 1200,
                        showConfirmButton: false
                    }).then(() => {
                        location.reload();
                    });
                },
                error: function() {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal',
                        text: 'Terjadi kesalahan.',
                        timer: 1200,
                        showConfirmButton: false
                    });
                }
            });
        });

    });
</script>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/layanan/script.blade.php ENDPATH**/ ?>