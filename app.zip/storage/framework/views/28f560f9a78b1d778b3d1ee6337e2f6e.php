

<?php $__env->startSection('content'); ?>
    <section class="container py-5">
        <h2 class="fw-bold text-center mb-4">Contact Us</h2>

        <div class="row justify-content-center">
            <div class="col-md-6" data-aos="fade-up">

                <form action="<?php echo e(route('contact.send')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label class="form-label">Name</label>
                        <input name="name" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input name="email" type="email" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Message</label>
                        <textarea name="message" rows="4" class="form-control" required></textarea>
                    </div>

                    <button class="btn btn-dark w-100 py-2 mt-2">Send Message</button>
                </form>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/website/pages/contact.blade.php ENDPATH**/ ?>