<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">Tambah Header Layanan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <div class="mb-3">
                    <label class="form-label">Title Tag</label>
                    <input type="text" id="add_title_tag" class="form-control">
                    <small class="text-danger" id="error_title_tag"></small>
                </div>

                <div class="mb-3">
                    <label class="form-label">Main Title</label>
                    <input type="text" id="add_main_title" class="form-control">
                    <small class="text-danger" id="error_main_title"></small>
                </div>

                <div class="mb-3">
                    <label class="form-label">Intro Text</label>
                    <textarea id="add_intro_text" cols="10" rows="5" class="form-control"></textarea>
                    <small class="text-danger" id="error_intro_text"></small>
                </div>

                <div class="mb-3">
                    <label class="form-label d-block">Flag Aktif</label>

                    <div class="form-check form-switch">
                        <input 
                            class="form-check-input" 
                            type="checkbox" 
                            id="add_flag_aktif"
                            value="1"
                        >
                        <label class="form-check-label" for="add_flag_aktif">Aktifkan</label>
                    </div>

                    <small class="text-muted">Default: Tidak aktif (0)</small>
                </div>

            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button class="btn btn-primary" id="btnSave">Simpan</button>
            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/layanan/header/add.blade.php ENDPATH**/ ?>