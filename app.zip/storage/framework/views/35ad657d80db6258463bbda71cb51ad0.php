<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">Edit Tentang Kami</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <input type="hidden" id="edit_id">

                <div class="row">

                    <div class="col-md-6 mb-3">
                        <label>Title Tag *</label>
                        <input type="text" id="edit_title_tag" class="form-control">
                        <small class="text-danger" id="edit_error_title_tag"></small>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label>Main Title *</label>
                        <input type="text" id="edit_main_title" class="form-control">
                        <small class="text-danger" id="edit_error_main_title"></small>
                    </div>

                    <div class="col-12 mb-3">
                        <label>Intro *</label>
                        <textarea id="edit_intro_text" rows="3" class="form-control"></textarea>
                        <small class="text-danger" id="edit_error_intro_text"></small>
                    </div>

                    
                    <div class="col-md-6 mb-3">
                        <label>Body Headline</label>
                        <input type="text" id="edit_body_headline" class="form-control">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label>Body Subheadline</label>
                        <input type="text" id="edit_body_subheadline" class="form-control">
                    </div>

                    <div class="col-12 mb-3">
                        <label>Paragraf 1</label>
                        <textarea id="edit_body_paragraf_1" rows="2" class="form-control"></textarea>
                    </div>

                    <div class="col-12 mb-3">
                        <label>Paragraf 2</label>
                        <textarea id="edit_body_paragraf_2" rows="2" class="form-control"></textarea>
                    </div>

                    
                    <?php for($i = 1; $i <= 3; $i++): ?>
                        <div class="col-md-6 mb-3">
                            <label>Award Title <?php echo e($i); ?></label>
                            <input type="text" id="edit_award_title<?php echo e($i); ?>" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Award Description <?php echo e($i); ?></label>
                            <input type="text" id="edit_award_desc<?php echo e($i); ?>" class="form-control">
                        </div>
                    <?php endfor; ?>

                    
                    <div class="col-12 mb-3">
                        <label>Gambar Baru (Opsional)</label>
                        <input type="file" id="edit_image" class="form-control">
                        <img id="preview_edit_image" class="img-fluid mt-2" style="max-height:150px; display:none;">
                    </div>

                </div>

            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button class="btn btn-primary" id="btnUpdate">Update</button>
            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/tentang-kami/edit.blade.php ENDPATH**/ ?>