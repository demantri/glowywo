<nav class="pc-sidebar">
    <div class="navbar-wrapper">

        <div class="m-header">
            <a href="#" class="b-brand text-primary">
                <h3>Glowy CMS</h3>
            </a>
        </div>

        <div class="navbar-content">
            <ul class="pc-navbar">

                <!-- Dashboard -->
                <li class="pc-item <?php echo e(request()->is('admin/dashboard') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('dashboard')); ?>" class="pc-link">
                        <span class="pc-micon"><i class="ti ti-dashboard"></i></span>
                        <span class="pc-mtext">Dashboard</span>
                    </a>
                </li>

                <!-- Konten Beranda -->
                <li class="pc-item">
                    <a href="<?php echo e(route('beranda.index')); ?>" class="pc-link">
                        <span class="pc-micon"><i class="ti ti-home"></i></span>
                        <span class="pc-mtext">Konten Beranda</span>
                    </a>
                </li>

                <!-- Profil Perusahaan -->
                <li class="pc-item">
                    <a href="<?php echo e(route('tentang-kami.index')); ?>" class="pc-link">
                        <span class="pc-micon"><i class="ti ti-info-circle"></i></span>
                        <span class="pc-mtext">Tentang Kami</span>
                    </a>
                </li>

                <!-- Layanan -->
                <li class="pc-item pc-hasmenu">
                    <a href="#!" class="pc-link">
                        <span class="pc-micon"><i class="ti ti-menu"></i></span>
                        <span class="pc-mtext">Layanan</span>
                        <span class="pc-arrow"><i data-feather="chevron-right"></i></span>
                    </a>

                    <ul class="pc-submenu">
                        <li class="pc-item">
                            <a class="pc-link" href="<?php echo e(route('header.layanan.index')); ?>">Header Section</a>
                        </li>

                        <li class="pc-item">
                            <a class="pc-link" href="<?php echo e(route('layanan.index')); ?>">Kelola Layanan</a>
                        </li>
                    </ul>
                </li>

                <!-- Testimoni -->
                <li class="pc-item pc-hasmenu">
                    <a href="#!" class="pc-link">
                        <span class="pc-micon"><i class="ti ti-menu"></i></span>
                        <span class="pc-mtext">Testimoni</span>
                        <span class="pc-arrow"><i data-feather="chevron-right"></i></span>
                    </a>

                    <ul class="pc-submenu">
                        <li class="pc-item">
                            <a class="pc-link" href="<?php echo e(route('header.testimoni.index')); ?>">Header Section</a>
                        </li>

                        <li class="pc-item">
                            <a class="pc-link" href="<?php echo e(route('testimoni.index')); ?>">Kelola Testimoni</a>
                        </li>
                    </ul>
                </li>

                <!-- Manajemen Galeri -->
                

                <!-- Manajemen Tim -->
                

                <!-- Pengaturan Website -->
                <li class="pc-item pc-hasmenu">
                    <a href="#!" class="pc-link">
                        <span class="pc-micon"><i class="ti ti-settings"></i></span>
                        <span class="pc-mtext">Pengaturan Website</span>
                        <span class="pc-arrow"><i data-feather="chevron-right"></i></span>
                    </a>

                    <ul class="pc-submenu">
                        <li class="pc-item">
                            <a class="pc-link" href="<?php echo e(route('perusahaan.index')); ?>">Pengaturan Perusahaan</a>
                        </li>

                        <li class="pc-item">
                            <a class="pc-link" href="<?php echo e(route('footer.index')); ?>">Pengaturan Footer</a>
                        </li>
                    </ul>
                </li>

                <!-- Manajemen Pengguna -->
                <li class="pc-item pc-hasmenu">
                    <a href="#!" class="pc-link">
                        <span class="pc-micon"><i class="ti ti-users"></i></span>
                        <span class="pc-mtext">Manajemen Pengguna</span>
                        <span class="pc-arrow"><i data-feather="chevron-right"></i></span>
                    </a>

                    <ul class="pc-submenu">
                        <li class="pc-item">
                            <a class="pc-link" href="<?php echo e(route('roles.index')); ?>">Manajemen Role</a>
                        </li>

                        <li class="pc-item">
                            <a class="pc-link" href="<?php echo e(route('users.index')); ?>">Daftar Pengguna</a>
                        </li>
                    </ul>
                </li>

            </ul>
        </div>
    </div>
</nav>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/template/sidebar.blade.php ENDPATH**/ ?>