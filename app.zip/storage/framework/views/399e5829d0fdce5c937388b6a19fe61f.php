

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card">

                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Profile Perusahaan</h5>
                    <button class="btn btn-primary" id="btnAdd">Tambah Data</button>
                </div>

                <div class="card-body">
                    <table class="table table-bordered table-striped" id="table" style="width: 100%">
                        <thead class="table-light">
                            <tr>
                                <th width="3%">#</th>
                                <th>Nama Perusahaan</th>
                                <th>Alias</th>
                                <th>Telp</th>
                                <th>WhatsApp</th>
                                <th>Alamat</th>
                                <th>Email</th>
                                <th>Logo Header</th>
                                <th>Logo Footer</th>
                                <th width="15%">Aksi</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->nama_perusahaan); ?></td>
                                    <td><?php echo e($item->alias_perusahaan); ?></td>
                                    <td><?php echo e($item->no_telp_kantor); ?></td>
                                    <td><?php echo e($item->no_whatsapp); ?></td>

                                    <td>
                                        <?php echo e(Str::limit($item->alamat_kantor, 40, '...')); ?>

                                    </td>

                                    <td><?php echo e($item->email_kantor); ?></td>

                                    
                                    <td class="text-center">
                                        <?php if($item->logo_header_path): ?>
                                            <img src="<?php echo e(asset('storage/' . $item->logo_header_path)); ?>"
                                                class="img-thumbnail"
                                                style="width: 60px; height: 60px; object-fit: contain;">
                                        <?php else: ?>
                                            <span class="badge bg-secondary">No Logo</span>
                                        <?php endif; ?>
                                    </td>

                                    
                                    <td class="text-center">
                                        <?php if($item->logo_footer_path): ?>
                                            <img src="<?php echo e(asset('storage/' . $item->logo_footer_path)); ?>"
                                                class="img-thumbnail"
                                                style="width: 60px; height: 60px; object-fit: contain;">
                                        <?php else: ?>
                                            <span class="badge bg-secondary">No Logo</span>
                                        <?php endif; ?>
                                    </td>

                                    <td class="text-center">
                                        <button class="btn btn-warning btn-sm btn-edit" data-id="<?php echo e($item->profile_id); ?>"
                                            data-nama="<?php echo e($item->nama_perusahaan); ?>"
                                            data-alias="<?php echo e($item->alias_perusahaan); ?>"
                                            data-telp="<?php echo e($item->no_telp_kantor); ?>" data-wa="<?php echo e($item->no_whatsapp); ?>"
                                            data-alamat="<?php echo e($item->alamat_kantor); ?>"
                                            data-email="<?php echo e($item->email_kantor); ?>"
                                            data-header="<?php echo e($item->logo_header_path); ?>"
                                            data-footer="<?php echo e($item->logo_footer_path); ?>">
                                            Edit
                                        </button>

                                        <button class="btn btn-danger btn-sm btn-delete" data-id="<?php echo e($item->profile_id); ?>">
                                            Hapus
                                        </button>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                </div>

            </div>
        </div>
    </div>

    <?php echo $__env->make('admin.perusahaan.add', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.perusahaan.edit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo $__env->make('admin.perusahaan.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/perusahaan/index.blade.php ENDPATH**/ ?>