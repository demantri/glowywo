<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">Tambah User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <div class="mb-3">
                    <label>Nama Lengkap</label>
                    <input type="text" id="add_name" class="form-control">
                    <small class="text-danger" id="error_name"></small>
                </div>

                <div class="mb-3">
                    <label>Username</label>
                    <input type="text" id="add_username" class="form-control">
                </div>

                <div class="mb-3">
                    <label>Email</label>
                    <input type="email" id="add_email" class="form-control">
                </div>

                <div class="mb-3">
                    <label>Password</label>
                    <input type="password" id="add_password" class="form-control">
                </div>

                <div class="mb-3">
                    <label>Role</label>
                    <select id="add_role" class="form-control">
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label>Foto</label>
                    <input type="file" id="add_photo" class="form-control">
                </div>

                <div class="mb-3">
                    <label>Sosial Media</label>
                    <input type="text" id="add_social" class="form-control">
                </div>

            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button class="btn btn-primary" id="btnSave">Simpan</button>
            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/user/add.blade.php ENDPATH**/ ?>