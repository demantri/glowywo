

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card">

                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Tentang Kami</h5>
                    <button class="btn btn-primary" id="btnAdd">Tambah Data</button>
                </div>

                <div class="card-body">

                    <?php if($data): ?>
                        <table class="table table-bordered">
                            <tr>
                                <th width="25%">Title Tag</th>
                                <td><?php echo e($data->title_tag); ?></td>
                            </tr>
                            <tr>
                                <th>Main Title</th>
                                <td><?php echo e($data->main_title); ?></td>
                            </tr>
                            <tr>
                                <th>Intro Text</th>
                                <td><?php echo e($data->intro_text); ?></td>
                            </tr>
                            <tr>
                                <th>Body Headline</th>
                                <td><?php echo e($data->body_headline); ?></td>
                            </tr>
                            <tr>
                                <th>Body Subheadline</th>
                                <td><?php echo e($data->body_subheadline); ?></td>
                            </tr>
                            <tr>
                                <th>Paragraf 1</th>
                                <td><?php echo e($data->body_paragraf_1); ?></td>
                            </tr>
                            <tr>
                                <th>Paragraf 2</th>
                                <td><?php echo e($data->body_paragraf_2); ?></td>
                            </tr>

                            
                            <tr>
                                <th colspan="2" class="text-center table-secondary">Awards</th>
                            </tr>

                            <tr>
                                <th>Award 1</th>
                                <td><strong><?php echo e($data->award_title1); ?></strong> <br> <?php echo e($data->award_desc1); ?></td>
                            </tr>

                            <tr>
                                <th>Award 2</th>
                                <td><strong><?php echo e($data->award_title2); ?></strong> <br> <?php echo e($data->award_desc2); ?></td>
                            </tr>

                            <tr>
                                <th>Award 3</th>
                                <td><strong><?php echo e($data->award_title3); ?></strong> <br> <?php echo e($data->award_desc3); ?></td>
                            </tr>

                            
                            <tr>
                                <th>Gambar</th>
                                <td>
                                    <?php if($data->image): ?>
                                        <img src="<?php echo e(asset('storage/' . $data->image)); ?>" width="200"
                                            class="rounded shadow">
                                    <?php else: ?>
                                        <small class="text-muted">Tidak ada gambar</small>
                                    <?php endif; ?>
                                </td>
                            </tr>

                            
                            <tr>
                                <td colspan="2" class="text-center">
                                    <button class="btn btn-warning btn-edit" data-id="<?php echo e($data->about_id); ?>"
                                        data-title_tag="<?php echo e($data->title_tag); ?>" data-main_title="<?php echo e($data->main_title); ?>"
                                        data-intro_text="<?php echo e($data->intro_text); ?>"
                                        data-body_headline="<?php echo e($data->body_headline); ?>"
                                        data-body_subheadline="<?php echo e($data->body_subheadline); ?>"
                                        data-body_paragraf_1="<?php echo e($data->body_paragraf_1); ?>"
                                        data-body_paragraf_2="<?php echo e($data->body_paragraf_2); ?>"
                                        data-award_title1="<?php echo e($data->award_title1); ?>"
                                        data-award_desc1="<?php echo e($data->award_desc1); ?>"
                                        data-award_title2="<?php echo e($data->award_title2); ?>"
                                        data-award_desc2="<?php echo e($data->award_desc2); ?>"
                                        data-award_title3="<?php echo e($data->award_title3); ?>"
                                        data-award_desc3="<?php echo e($data->award_desc3); ?>">Edit</button>

                                    <button class="btn btn-danger btn-delete" data-id="<?php echo e($data->about_id); ?>">
                                        Hapus
                                    </button>
                                </td>
                            </tr>
                        </table>
                    <?php else: ?>
                        <p class="text-muted text-center">Belum ada data.</p>
                    <?php endif; ?>

                </div>

            </div>
        </div>
    </div>

    <?php echo $__env->make('admin.tentang-kami.add', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.tentang-kami.edit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo $__env->make('admin.tentang-kami.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/tentang-kami/index.blade.php ENDPATH**/ ?>