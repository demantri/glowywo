<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Testimoni Klien</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa, #e6ecf5, #f0f4ff);
            min-height: 100vh;
            display: flex;
            align-items: center;
        }

        .testi-card {
            border: none;
            border-radius: 18px;
            backdrop-filter: blur(12px);
            background: rgba(255, 255, 255, 0.85);
            box-shadow: 0 10px 30px rgba(0, 0, 0, .1);
            padding: 35px;
        }

        .section-title {
            font-weight: 700;
            font-size: 32px;
            color: #2b2d42;
        }

        .section-sub {
            color: #6c757d;
            font-size: 15px;
        }

        /* Floating Label Style */
        .form-floating-custom {
            position: relative;
            margin-bottom: 1rem;
        }

        .form-floating-custom input,
        .form-floating-custom textarea {
            border-radius: 10px;
            border: 1.6px solid #d8dce6;
            padding: 14px 16px;
            background: #fff;
            transition: border .2s;
        }

        .form-floating-custom input:focus,
        .form-floating-custom textarea:focus {
            border-color: #5b7fff;
            box-shadow: 0 0 0 0.15rem rgba(91, 127, 255, .15);
        }

        .form-floating-custom label {
            position: absolute;
            top: -10px;
            left: 14px;
            background: #fff;
            padding: 0 6px;
            font-size: 12px;
            color: #6c757d;
        }

        /* Rating Star Premium */
        .rating-wrapper {
            display: flex;
            gap: 12px;
            justify-content: start;
            margin-bottom: 10px;
        }

        .rating-wrapper input {
            display: none;
        }

        .rating-wrapper label {
            font-size: 45px;
            cursor: pointer;
            transition: 0.25s;
            color: #dcdcdc;
        }

        .rating-wrapper input:checked~label,
        .rating-wrapper label:hover,
        .rating-wrapper label:hover~label {
            color: #ffc107;
            transform: scale(1.1);
        }

        /* Foto Preview */
        #previewFoto {
            width: 110px;
            height: 110px;
            border-radius: 12px;
            border: 1px solid #ddd;
            object-fit: cover;
            display: none;
            margin-top: 10px;
        }

        .btn-premium {
            background: linear-gradient(90deg, #5b7fff, #6f9aff);
            border: none;
            padding: 12px;
            font-weight: 600;
            border-radius: 12px;
        }

        .btn-premium:hover {
            opacity: .9;
        }
    </style>
</head>

<body>

    <div class="container" style="max-width: 750px;">
        <div class="testi-card mx-auto">
            <h2 class="section-title text-center mb-1">Berikan Testimoni Anda</h2>
            <p class="section-sub text-center mb-4">
                Pendapat Anda sangat berarti untuk meningkatkan kualitas layanan kami.
            </p>

            <?php if(session('success')): ?>
                <div class="alert alert-success text-center mb-4"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <form action="<?php echo e(route('testimoni.public.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                
                <div class="form-floating-custom">
                    <label>Nama Klien *</label>
                    <input type="text" name="nama_klien" class="form-control" placeholder="Nama Klien"
                        value="<?php echo e(old('nama_klien')); ?>">
                    <?php $__errorArgs = ['nama_klien'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="form-floating-custom">
                    <label>Ulasan *</label>
                    <textarea name="ulasan_text" class="form-control" rows="4" placeholder="Ceritakan pengalaman Anda..."><?php echo e(old('ulasan_text')); ?></textarea>
                    <small id="charCount" class="text-muted d-block mt-1">0 / 300 kata</small>
                    <?php $__errorArgs = ['ulasan_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <label class="fw-semibold mb-1">Rating Bintang *</label>

                <div class="rating-wrapper mb-1">
                    <input type="radio" id="star5" name="rating_star" value="5"><label
                        for="star5">⭐</label>
                    <input type="radio" id="star4" name="rating_star" value="4"><label
                        for="star4">⭐</label>
                    <input type="radio" id="star3" name="rating_star" value="3"><label
                        for="star3">⭐</label>
                    <input type="radio" id="star2" name="rating_star" value="2"><label
                        for="star2">⭐</label>
                    <input type="radio" id="star1" name="rating_star" value="1"><label
                        for="star1">⭐</label>
                </div>

                
                <p class="text-muted mt-1" id="ratingInfo" style="display:none;">
                    Anda memilih rating: <strong id="ratingValue"></strong> / 5
                </p>

                <?php $__errorArgs = ['rating_star'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                
                <button class="btn btn-premium w-100 mt-4">Kirim Testimoni</button>
            </form>
        </div>
    </div>

    <script>
        document.querySelector("textarea[name='ulasan_text']").addEventListener("input", function() {
            const text = this.value;
            const count = text.length;

            const info = document.getElementById("charCount");
            info.textContent = `${count} / 300 karakter`;

            if (count > 300) {
                info.style.color = "red";
            } else {
                info.style.color = "#6c757d";
            }
        });

        // tampilkan rating yg dipilih
        document.querySelectorAll('.rating-wrapper input').forEach((radio) => {
            radio.addEventListener('change', function() {
                const rating = this.value;
                document.getElementById('ratingValue').textContent = rating;
                document.getElementById('ratingInfo').style.display = 'block';
            });
        });
    </script>

</body>

</html>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/public/testimoni/form.blade.php ENDPATH**/ ?>