<section id="why-us" class="why-us section">

    <!-- Section Title -->
    <div class="container section-title" data-aos="fade-up">
        <span class="subtitle">Why Us</span>
        <h2>Why Choose Us</h2>
        <p>Necessitatibus eius consequatur ex aliquid fuga eum quidem sint consectetur velit. Sed ut
            perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium totam rem
            aperiam</p>
    </div><!-- End Section Title -->

    <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row">
            <div class="col-lg-6" data-aos="fade-right" data-aos-delay="200">
                <div class="content">
                    <h2>Why Partner With Us</h2>
                    <p>We deliver exceptional results through proven expertise, cutting-edge innovation, and
                        unwavering commitment to your success. Our comprehensive approach ensures sustainable
                        growth and competitive advantage.</p>
                </div>
            </div>
            <div class="col-lg-6" data-aos="fade-left" data-aos-delay="300">
                <div class="image-wrapper">
                    <img src="<?php echo e(asset('website/assets/img/about/about-8.webp')); ?>" alt="Professional team collaboration" class="img-fluid">
                </div>
            </div>
        </div>

        <div class="features-grid" data-aos="fade-up" data-aos-delay="400">
            <div class="row g-5">

                <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
                    <div class="feature-item">
                        <div class="icon-wrapper">
                            <i class="bi bi-lightbulb"></i>
                        </div>
                        <div class="feature-content">
                            <h3>Innovation Leadership</h3>
                            <p>We stay ahead of industry trends, implementing cutting-edge technologies and
                                methodologies that drive transformational results for your business growth.</p>
                        </div>
                    </div>
                </div><!-- End Feature Item -->

                <div class="col-lg-6" data-aos="fade-up" data-aos-delay="200">
                    <div class="feature-item">
                        <div class="icon-wrapper">
                            <i class="bi bi-award"></i>
                        </div>
                        <div class="feature-content">
                            <h3>Proven Expertise</h3>
                            <p>Our team brings decades of combined experience across multiple industries,
                                ensuring strategic insights and tactical execution that delivers measurable
                                outcomes.</p>
                        </div>
                    </div>
                </div><!-- End Feature Item -->

                <div class="col-lg-6" data-aos="fade-up" data-aos-delay="300">
                    <div class="feature-item">
                        <div class="icon-wrapper">
                            <i class="bi bi-headset"></i>
                        </div>
                        <div class="feature-content">
                            <h3>24/7 Dedicated Support</h3>
                            <p>Round-the-clock availability with personalized attention from dedicated account
                                managers who understand your unique challenges and objectives.</p>
                        </div>
                    </div>
                </div><!-- End Feature Item -->

                <div class="col-lg-6" data-aos="fade-up" data-aos-delay="400">
                    <div class="feature-item">
                        <div class="icon-wrapper">
                            <i class="bi bi-graph-up-arrow"></i>
                        </div>
                        <div class="feature-content">
                            <h3>Cost Efficiency</h3>
                            <p>Streamlined processes and intelligent resource allocation reduce overhead while
                                maximizing ROI, delivering premium results within your budget parameters.</p>
                        </div>
                    </div>
                </div><!-- End Feature Item -->

            </div>
        </div>

    </div>

</section>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/website/why-us.blade.php ENDPATH**/ ?>