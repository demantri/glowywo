<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">Edit Data Beranda</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <input type="hidden" id="edit_id">

                <div class="row">

                    <div class="col-md-12 mb-3">
                        <label class="form-label">Hero Headline *</label>
                        <input type="text" id="edit_hero_headline" class="form-control">
                        <small class="text-danger" id="edit_error_hero_headline"></small>
                    </div>

                    <div class="col-md-12 mb-3">
                        <label>Hero Subtext *</label>
                        <textarea id="edit_hero_subtext" rows="3" class="form-control"></textarea>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label>Primary Button *</label>
                        <input type="text" id="edit_btn_primary_text" class="form-control">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label>Secondary Button *</label>
                        <input type="text" id="edit_btn_secondary_text" class="form-control">
                    </div>

                    
                    <h6 class="mt-3">Statistik</h6>

                    <div class="col-md-3 mb-3">
                        <label>Stat 1 Value</label>
                        <input type="text" id="edit_stat_1_value" class="form-control">
                    </div>
                    <div class="col-md-9 mb-3">
                        <label>Stat 1 Label</label>
                        <input type="text" id="edit_stat_1_label" class="form-control">
                    </div>

                    <div class="col-md-3 mb-3">
                        <label>Stat 2 Value</label>
                        <input type="text" id="edit_stat_2_value" class="form-control">
                    </div>
                    <div class="col-md-9 mb-3">
                        <label>Stat 2 Label</label>
                        <input type="text" id="edit_stat_2_label" class="form-control">
                    </div>

                    <div class="col-md-3 mb-3">
                        <label>Stat 3 Value</label>
                        <input type="text" id="edit_stat_3_value" class="form-control">
                    </div>
                    <div class="col-md-9 mb-3">
                        <label>Stat 3 Label</label>
                        <input type="text" id="edit_stat_3_label" class="form-control">
                    </div>

                    
                    <div class="col-md-12 mb-3">
                        <label>Upload Gambar Baru (Opsional)</label>
                        <input type="file" id="edit_image" class="form-control">
                        <img id="preview_edit_image" class="img-fluid mt-2" style="max-height:150px; display:none;">
                    </div>

                </div>

            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button class="btn btn-primary" id="btnUpdate">Update</button>
            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/beranda/edit.blade.php ENDPATH**/ ?>