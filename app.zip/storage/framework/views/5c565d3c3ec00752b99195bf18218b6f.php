

<?php $__env->startSection('content'); ?>
    <!-- HERO -->
    <section class="container text-center py-5">
        <div class="row align-items-center" data-aos="fade-up">
            <div class="col-lg-12">
                <h1 class="hero-text mb-3">Make Your Moment Truly Unforgettable</h1>
                <p class="text-muted fs-5">Professional Wedding & Event Organizer</p>

                <div class="d-flex justify-content-center gap-3 mt-4 flex-wrap">
                    <a href="<?php echo e(route('wedding')); ?>" class="btn soft-pink px-4 py-2 fw-semibold">
                        Wedding Organizer
                    </a>

                    <a href="<?php echo e(route('event')); ?>" class="btn soft-blue px-4 py-2 fw-semibold">
                        Event Organizer
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- SERVICES -->
    <section class="container py-5">
        <h2 class="text-center mb-5 fw-bold" data-aos="fade-up">
            Our Services
        </h2>

        <div class="row g-4">
            <div class="col-md-3" data-aos="fade-up">
                <div class="p-4 border rounded text-center shadow-sm">
                    <h3>💍</h3>
                    <h5 class="fw-bold mt-2">Wedding Organizer</h5>
                </div>
            </div>

            <div class="col-md-3" data-aos="fade-up">
                <div class="p-4 border rounded text-center shadow-sm">
                    <h3>🎤</h3>
                    <h5 class="fw-bold mt-2">Event Organizer</h5>
                </div>
            </div>

            <div class="col-md-3" data-aos="fade-up">
                <div class="p-4 border rounded text-center shadow-sm">
                    <h3>📸</h3>
                    <h5 class="fw-bold mt-2">Documentation</h5>
                </div>
            </div>

            <div class="col-md-3" data-aos="fade-up">
                <div class="p-4 border rounded text-center shadow-sm">
                    <h3>🎨</h3>
                    <h5 class="fw-bold mt-2">Decoration</h5>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA -->
    <section class="soft-gold py-5 text-center mt-5" data-aos="fade-up">
        <h2 class="fw-bold">Planning an Event?</h2>
        <p class="mb-4">Let’s make your moment unforgettable together.</p>
        <a href="<?php echo e(route('contact')); ?>" class="btn btn-dark px-5 py-2">Contact Us</a>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/website/pages/home.blade.php ENDPATH**/ ?>