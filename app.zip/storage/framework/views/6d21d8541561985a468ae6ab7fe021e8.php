<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">Tambah Profile Perusahaan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <div class="row">

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Nama Perusahaan</label>
                        <input type="text" id="add_nama_perusahaan" class="form-control">
                        <small class="text-danger" id="error_nama_perusahaan"></small>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Alias Perusahaan</label>
                        <input type="text" id="add_alias_perusahaan" class="form-control">
                        <small class="text-danger" id="error_alias_perusahaan"></small>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">No. Telp Kantor</label>
                        <input type="text" id="add_no_telp" class="form-control">
                        <small class="text-danger" id="error_no_telp"></small>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">No. WhatsApp</label>
                        <input type="text" id="add_no_wa" class="form-control">
                        <small class="text-danger" id="error_no_wa"></small>
                    </div>

                    <div class="col-md-12 mb-3">
                        <label class="form-label">Alamat Kantor</label>
                        <textarea id="add_alamat" class="form-control" rows="3"></textarea>
                        <small class="text-danger" id="error_alamat"></small>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Email Kantor</label>
                        <input type="text" id="add_email_kantor" class="form-control">
                        <small class="text-danger" id="error_email_kantor"></small>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Logo Header</label>
                        <input type="file" id="add_logo_header" class="form-control">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Logo Footer</label>
                        <input type="file" id="add_logo_footer" class="form-control">
                    </div>

                </div>

            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button class="btn btn-primary" id="btnSave">Simpan</button>
            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/perusahaan/add.blade.php ENDPATH**/ ?>