<script>
    $(document).ready(function() {
        $("#roleTable").DataTable();

        // Add Modal
        $("#btnAdd").click(function() {
            $("#addModal").modal('show');
        });


        // ============================
        // ADD ROLE (AJAX)
        // ============================
        $("#btnSave").click(function() {
            $("#add_error_name").text("");

            $.ajax({
                url: "<?php echo e(route('roles.store')); ?>",
                method: "POST",
                data: {
                    name: $("#add_name").val(),
                    description: $("#add_description").val(),
                    _token: "<?php echo e(csrf_token()); ?>"
                },
                success: function(res) {
                    $("#addModal").modal('hide');

                    toastr.success("Role berhasil ditambahkan!");

                    setTimeout(function() {
                        location.reload();
                    }, 800);
                },
                error: function(err) {
                    if (err.status === 422) {
                        $("#add_error_name").text(err.responseJSON.errors.name);
                    }
                }
            });
        });


        // ============================
        // SHOW EDIT MODAL
        // ============================
        $(".btn-edit").click(function() {
            let id = $(this).data("id");
            let name = $(this).data("name");
            let desc = $(this).data("desc");

            $("#edit_id").val(id);
            $("#edit_name").val(name);
            $("#edit_description").val(desc);

            $("#editModal").modal('show');
        });


        // ============================
        // UPDATE ROLE (AJAX)
        // ============================
        $("#btnUpdate").click(function() {
            let id = $("#edit_id").val();
            $("#edit_error_name").text("");

            $.ajax({
                url: "/admin/roles/" + id,
                method: "PUT",
                data: {
                    name: $("#edit_name").val(),
                    description: $("#edit_description").val(),
                    _token: "<?php echo e(csrf_token()); ?>"
                },
                success: function(res) {
                    $("#editModal").modal('hide');

                    toastr.success("Role berhasil diperbarui!");

                    setTimeout(function() {
                        location.reload();
                    }, 800);
                },
                error: function(err) {
                    if (err.status === 422) {
                        $("#edit_error_name").text(err.responseJSON.errors.name);
                    }
                }
            });
        });


        // ============================
        // DELETE ROLE (AJAX) + SWEETALERT
        // ============================
        $(".btn-delete").click(function() {
            let id = $(this).data("id");

            Swal.fire({
                title: "Yakin hapus?",
                text: "Data ini akan dihapus permanen!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "Ya, hapus!",
                cancelButtonText: "Batal",
                confirmButtonColor: "#d33",
                cancelButtonColor: "#3085d6",
            }).then((result) => {
                if (result.isConfirmed) {

                    $.ajax({
                        url: "/admin/roles/" + id,
                        method: "DELETE",
                        data: {
                            _token: "<?php echo e(csrf_token()); ?>"
                        },
                        success: function(res) {
                            toastr.success("Role berhasil dihapus!");

                            setTimeout(function() {
                                location.reload();
                            }, 600);
                        }
                    });

                }
            });
        });

    });
</script>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/role/script.blade.php ENDPATH**/ ?>