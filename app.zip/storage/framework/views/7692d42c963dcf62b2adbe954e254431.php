<script>
    $(function() {

        $("#table").DataTable({
            scrollX: true,
        });

        $("#btnAdd").click(function() {
            $("#addModal").modal('show');
        });

        $("#btnSave").click(function() {

            let formData = new FormData();
            formData.append("_token", "<?php echo e(csrf_token()); ?>");

            formData.append("nama_perusahaan", $("#add_nama_perusahaan").val());
            formData.append("alias_perusahaan", $("#add_alias_perusahaan").val());
            formData.append("no_telp_kantor", $("#add_no_telp").val());
            formData.append("no_whatsapp", $("#add_no_wa").val());
            formData.append("alamat_kantor", $("#add_alamat").val());
            formData.append("email_kantor", $("#add_email_kantor").val());

            if ($("#add_logo_header")[0].files[0]) {
                formData.append("logo_header", $("#add_logo_header")[0].files[0]);
            }
            if ($("#add_logo_footer")[0].files[0]) {
                formData.append("logo_footer", $("#add_logo_footer")[0].files[0]);
            }

            $.ajax({
                url: "<?php echo e(route('perusahaan.store')); ?>",
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,

                success(res) {
                    $("#addModal").modal("hide");
                    $(".modal-backdrop").remove();
                    Swal.fire({
                        icon: "success",
                        title: "Berhasil!",
                        text: res.message,
                        timer: 1000,
                        showConfirmButton: false
                    }).then(() => location.reload());
                },

                error(xhr) {
                    let e = xhr.responseJSON.errors;
                    $("#error_nama_perusahaan").text(e?.nama_perusahaan ?? "");
                    $("#error_alias_perusahaan").text(e?.alias_perusahaan ?? "");
                }
            });

        });

        // ========================
        // OPEN EDIT MODAL
        // ========================
        $(".btn-edit").click(function() {

            let id = $(this).data("id");
            let nama = $(this).data("nama");
            let alias = $(this).data("alias");
            let telp = $(this).data("telp");
            let wa = $(this).data("wa");
            let alamat = $(this).data("alamat");
            let email = $(this).data("email");
            let header = $(this).data("header");
            let footer = $(this).data("footer");

            // Fill form
            $("#edit_profile_id").val(id);
            $("#edit_nama_perusahaan").val(nama);
            $("#edit_alias_perusahaan").val(alias);
            $("#edit_no_telp").val(telp);
            $("#edit_no_wa").val(wa);
            $("#edit_alamat").val(alamat);
            $("#edit_email_kantor").val(email);

            // Preview logo header
            if (header) {
                $("#preview_logo_header").attr("src", "/storage/" + header).show();
            } else {
                $("#preview_logo_header").hide();
            }

            // Preview logo footer
            if (footer) {
                $("#preview_logo_footer").attr("src", "/storage/" + footer).show();
            } else {
                $("#preview_logo_footer").hide();
            }

            $("#editModal").modal("show");
        });


        // ========================
        // UPDATE DATA PERUSAHAAN
        // ========================
        $("#btnUpdate").click(function() {

            let id = $("#edit_profile_id").val();

            let formData = new FormData();
            formData.append("_token", "<?php echo e(csrf_token()); ?>");
            formData.append("_method", "PUT");

            formData.append("nama_perusahaan", $("#edit_nama_perusahaan").val());
            formData.append("alias_perusahaan", $("#edit_alias_perusahaan").val());
            formData.append("no_telp_kantor", $("#edit_no_telp").val());
            formData.append("no_whatsapp", $("#edit_no_wa").val());
            formData.append("alamat_kantor", $("#edit_alamat").val());
            formData.append("email_kantor", $("#edit_email_kantor").val());

            // Upload new header logo if selected
            if ($("#edit_logo_header")[0].files[0]) {
                formData.append("logo_header", $("#edit_logo_header")[0].files[0]);
            }

            // Upload new footer logo if selected
            if ($("#edit_logo_footer")[0].files[0]) {
                formData.append("logo_footer", $("#edit_logo_footer")[0].files[0]);
            }

            // Clear errors
            $(".error-text").text("");

            $.ajax({
                url: "/admin/perusahaan/" + id,
                method: "POST",
                data: formData,
                contentType: false,
                processData: false,

                success: function(res) {
                    $("#editModal").modal("hide");
                    $(".modal-backdrop").remove();
                    Swal.fire({
                        icon: "success",
                        title: "Berhasil!",
                        text: res.message,
                        timer: 1200,
                        showConfirmButton: false
                    }).then(() => {
                        location.reload();
                    });
                },

                error: function(xhr) {
                    if (xhr.status === 422) {
                        let err = xhr.responseJSON.errors;

                        $("#edit_error_nama_perusahaan").text(err?.nama_perusahaan ?? "");
                        $("#edit_error_alias_perusahaan").text(err?.alias_perusahaan ?? "");
                        $("#edit_error_no_telp").text(err?.no_telp_kantor ?? "");
                        $("#edit_error_no_wa").text(err?.no_whatsapp ?? "");
                        $("#edit_error_alamat").text(err?.alamat_kantor ?? "");
                        $("#edit_error_email_kantor").text(err?.email_kantor ?? "");
                    } else {
                        Swal.fire("Gagal!", "Terjadi kesalahan server.", "error");
                    }
                }

            });

        });

        $(".btn-delete").click(function() {

            let id = $(this).data("id");

            Swal.fire({
                title: "Hapus Footer?",
                text: "Data ini tidak bisa dikembalikan!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "Ya, hapus",
                cancelButtonText: "Batal"
            }).then((r) => {

                if (r.isConfirmed) {
                    $.ajax({
                        url: "/admin/perusahaan/" + id,
                        method: "DELETE",
                        data: {
                            _token: "<?php echo e(csrf_token()); ?>"
                        },

                        success() {
                            Swal.fire("Berhasil!", "Data footer dihapus.", "success");
                            setTimeout(() => location.reload(), 800);
                        }
                    });
                }
            });

        });
    });
</script>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/perusahaan/script.blade.php ENDPATH**/ ?>