<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">Tambah Tentang Kami</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <div class="row">

                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Title Tag *</label>
                        <input type="text" id="add_title_tag" class="form-control">
                        <small class="text-danger" id="error_add_title_tag"></small>
                    </div>

                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Main Title *</label>
                        <input type="text" id="add_main_title" class="form-control">
                        <small class="text-danger" id="error_add_main_title"></small>
                    </div>

                    
                    <div class="col-12 mb-3">
                        <label class="form-label">Intro Text *</label>
                        <textarea id="add_intro_text" class="form-control" rows="3"></textarea>
                        <small class="text-danger" id="error_add_intro_text"></small>
                    </div>

                    
                    <div class="col-md-6 mb-3">
                        <label>Body Headline</label>
                        <input type="text" id="add_body_headline" class="form-control">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label>Body Subheadline</label>
                        <input type="text" id="add_body_subheadline" class="form-control">
                    </div>

                    <div class="col-12 mb-3">
                        <label>Paragraf 1</label>
                        <textarea id="add_body_paragraf_1" rows="2" class="form-control"></textarea>
                    </div>

                    <div class="col-12 mb-3">
                        <label>Paragraf 2</label>
                        <textarea id="add_body_paragraf_2" rows="2" class="form-control"></textarea>
                    </div>

                    
                    <h6 class="mt-3">Awards</h6>

                    <?php for($i = 1; $i <= 3; $i++): ?>
                        <div class="col-md-6 mb-3">
                            <label>Award Title <?php echo e($i); ?></label>
                            <input type="text" id="add_award_title<?php echo e($i); ?>" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Award Description <?php echo e($i); ?></label>
                            <input type="text" id="add_award_desc<?php echo e($i); ?>" class="form-control">
                        </div>
                    <?php endfor; ?>

                    
                    <div class="col-12 mb-3">
                        <label>Gambar</label>
                        <input type="file" id="add_image" class="form-control">
                        <img id="preview_add_image" class="img-fluid mt-2" style="max-height:150px; display:none;">
                    </div>

                </div>

            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button class="btn btn-primary" id="btnSave">Simpan</button>
            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/tentang-kami/add.blade.php ENDPATH**/ ?>