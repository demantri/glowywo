<script>
    $(function() {

        // OPEN ADD MODAL
        $("#btnAdd").click(function() {
            $("#addModal").modal("show");
        });

        // PREVIEW ADD IMAGE
        $("#add_image").change(function() {
            let img = URL.createObjectURL(this.files[0]);
            $("#preview_add_image").attr("src", img).show();
        });

        // SAVE DATA
        $("#btnSave").click(function() {

            let formData = new FormData();
            formData.append("title_tag", $("#add_title_tag").val());
            formData.append("main_title", $("#add_main_title").val());
            formData.append("intro_text", $("#add_intro_text").val());

            formData.append("body_headline", $("#add_body_headline").val());
            formData.append("body_subheadline", $("#add_body_subheadline").val());
            formData.append("body_paragraf_1", $("#add_body_paragraf_1").val());
            formData.append("body_paragraf_2", $("#add_body_paragraf_2").val());

            for (let i = 1; i <= 3; i++) {
                formData.append(`award_title${i}`, $(`#add_award_title${i}`).val());
                formData.append(`award_desc${i}`, $(`#add_award_desc${i}`).val());
            }

            if ($("#add_image")[0].files[0]) {
                formData.append("image", $("#add_image")[0].files[0]);
            }

            formData.append("_token", "<?php echo e(csrf_token()); ?>");

            $.ajax({
                url: "<?php echo e(route('tentang-kami.store')); ?>",
                method: "POST",
                data: formData,
                contentType: false,
                processData: false,

                success: function(res) {
                    $("#addModal").modal("hide");
                    $(".modal-backdrop").remove();
                    Swal.fire("Berhasil", res.message, "success").then(() => {
                        location.reload();
                    });
                },

                error: function(err) {
                    Swal.fire("Gagal", "Periksa input Anda", "error");
                }
            });

        });

        // ===========================================
        // EDIT
        // ===========================================

        $(".btn-edit").click(function() {

            $("#edit_id").val($(this).data("id"));
            $("#edit_title_tag").val($(this).data("title_tag"));
            $("#edit_main_title").val($(this).data("main_title"));
            $("#edit_intro_text").val($(this).data("intro_text"));
            $("#edit_body_headline").val($(this).data("body_headline"));
            $("#edit_body_subheadline").val($(this).data("body_subheadline"));
            $("#edit_body_paragraf_1").val($(this).data("body_paragraf_1"));
            $("#edit_body_paragraf_2").val($(this).data("body_paragraf_2"));

            for (let i = 1; i <= 3; i++) {
                $(`#edit_award_title${i}`).val($(this).data(`award_title${i}`));
                $(`#edit_award_desc${i}`).val($(this).data(`award_desc${i}`));
            }

            $("#editModal").modal("show");
        });

        // PREVIEW EDIT IMAGE
        $("#edit_image").change(function() {
            let img = URL.createObjectURL(this.files[0]);
            $("#preview_edit_image").attr("src", img).show();
        });

        // UPDATE DATA
        $("#btnUpdate").click(function() {

            let id = $("#edit_id").val();
            let formData = new FormData();

            formData.append("title_tag", $("#edit_title_tag").val());
            formData.append("main_title", $("#edit_main_title").val());
            formData.append("intro_text", $("#edit_intro_text").val());
            formData.append("body_headline", $("#edit_body_headline").val());
            formData.append("body_subheadline", $("#edit_body_subheadline").val());
            formData.append("body_paragraf_1", $("#edit_body_paragraf_1").val());
            formData.append("body_paragraf_2", $("#edit_body_paragraf_2").val());

            for (let i = 1; i <= 3; i++) {
                formData.append(`award_title${i}`, $(`#edit_award_title${i}`).val());
                formData.append(`award_desc${i}`, $(`#edit_award_desc${i}`).val());
            }

            if ($("#edit_image")[0].files[0]) {
                formData.append("image", $("#edit_image")[0].files[0]);
            }

            formData.append("_token", "<?php echo e(csrf_token()); ?>");
            formData.append("_method", "PUT");

            $.ajax({
                url: "/admin/tentang-kami/" + id,
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,

                success: function(res) {
                    $("#editModal").modal("hide");
                    $(".modal-backdrop").remove();
                    Swal.fire("Berhasil", res.message, "success").then(() => {
                        location.reload();
                    });
                },

                error: function() {
                    Swal.fire("Gagal", "Periksa input Anda", "error");
                }
            });

        });

        // DELETE
        $(".btn-delete").click(function() {
            let id = $(this).data("id");

            Swal.fire({
                title: "Yakin ingin menghapus?",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "Hapus",
                cancelButtonText: "Batal"
            }).then(result => {
                if (result.isConfirmed) {

                    $.ajax({
                        url: "/admin/tentang-kami/" + id,
                        method: "DELETE",
                        data: {
                            _token: "<?php echo e(csrf_token()); ?>"
                        },

                        success: function(res) {
                            Swal.fire("Berhasil", res.message, "success").then(() =>
                                location.reload());
                        }
                    });

                }
            });
        });

    });
</script>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/tentang-kami/script.blade.php ENDPATH**/ ?>