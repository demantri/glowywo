

<?php $__env->startSection('content'); ?>
    <section class="hero-wedding d-flex align-items-center">
        <div class="container text-center text-white" data-aos="fade-up">

            <h1 class="fw-bold display-4 mb-3">
                Elegant & Unforgettable Weddings
            </h1>

            <p class="lead mb-4">
                Kami menciptakan momen pernikahan yang indah, berkesan, dan penuh makna.
            </p>

            <div class="d-flex justify-content-center gap-3 flex-wrap">
                <a href="<?php echo e(route('wedding')); ?>" class="btn btn-light px-4 py-2 fw-semibold">
                    Explore Packages
                </a>
                <a href="<?php echo e(route('portfolio')); ?>" class="btn btn-outline-light px-4 py-2 fw-semibold">
                    See Portfolio
                </a>
            </div>

        </div>
    </section>

    <style>
        .hero-wedding {
            background-image: linear-gradient(rgba(0, 0, 0, 0.45),
                    rgba(0, 0, 0, 0.45)),
                url('/images/hero-wedding.jpg');
            /* Ganti sesuai file */
            background-size: cover;
            background-position: center;
            height: 90vh;
            border-radius: 0 0 40px 40px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/website/pages/wedding.blade.php ENDPATH**/ ?>