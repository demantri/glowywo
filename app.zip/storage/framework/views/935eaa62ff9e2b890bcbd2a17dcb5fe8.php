<script>
    $(function() {

        $("#table").DataTable();

        $("#btnAdd").click(function() {
            $("#addModal").modal('show');
        });

        // Tombol simpan
        $('#btnSave').on('click', function() {

            // Ambil nilai form
            let title_tag = $('#add_title_tag').val();
            let main_title = $('#add_main_title').val();
            let intro_text = $('#add_intro_text').val();
            let flag_aktif = $('#add_flag_aktif').is(':checked') ? 1 : 0;

            // Reset error dulu
            $('#error_title_tag').text('');
            $('#error_main_title').text('');
            $('#error_intro_text').text('');

            $.ajax({
                url: "<?php echo e(route('header.layanan.store')); ?>",
                type: "POST",
                data: {
                    title_tag: title_tag,
                    main_title: main_title,
                    intro_text: intro_text,
                    flag_aktif: flag_aktif,
                    _token: "<?php echo e(csrf_token()); ?>"
                },
                success: function(res) {
                    $("#addModal").modal("hide");
                    $(".modal-backdrop").remove();
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil',
                        text: res.message,
                        timer: 1200,
                        showConfirmButton: false
                    }).then(() => {
                        location.reload();
                    });

                },
                error: function(xhr) {
                    if (xhr.status === 422) {
                        let errors = xhr.responseJSON.errors;

                        if (errors.title_tag) {
                            $('#error_title_tag').text(errors.title_tag[0]);
                        }

                        if (errors.main_title) {
                            $('#error_main_title').text(errors.main_title[0]);
                        }

                        if (errors.intro_text) {
                            $('#error_intro_text').text(errors.intro_text[0]);
                        }

                        Swal.fire({
                            icon: 'error',
                            title: 'Validasi gagal',
                            text: 'Periksa input form Anda.',
                            timer: 1500,
                            showConfirmButton: false
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Gagal',
                            text: 'Terjadi kesalahan server.',
                            timer: 1500,
                            showConfirmButton: false
                        });
                    }
                }
            });

        });

        $(".btn-edit").click(function() {

            let id = $(this).data("id");
            let title_tag = $(this).data("title_tag");
            let main_title = $(this).data("main_title");
            let intro_text = $(this).data("intro_text");
            let flag_aktif = $(this).data("flag_aktif");

            // Set value ke form edit
            $("#edit_id").val(id);
            $("#edit_title_tag").val(title_tag);
            $("#edit_main_title").val(main_title);
            $("#edit_intro_text").val(intro_text);

            // Switch Flag Aktif
            if (flag_aktif == 1) {
                $("#edit_flag_aktif").prop("checked", true);
            } else {
                $("#edit_flag_aktif").prop("checked", false);
            }

            // Buka modal
            $("#editModal").modal("show");
        });

        $("#btnUpdate").click(function() {

            let id = $("#edit_id").val();

            // Reset error message
            $("#edit_error_title_tag").text("");
            $("#edit_error_main_title").text("");
            $("#edit_error_intro_text").text("");

            let flag_aktif = $("#edit_flag_aktif").is(":checked") ? 1 : 0;

            $.ajax({
                url: "/admin/testimoni/header/" + id, // sesuaikan route
                method: "POST",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    _method: "PUT",
                    title_tag: $("#edit_title_tag").val(),
                    main_title: $("#edit_main_title").val(),
                    intro_text: $("#edit_intro_text").val(),
                    flag_aktif: flag_aktif
                },

                success: function(res) {
                    $("#editModal").modal("hide");
                    $(".modal-backdrop").remove();

                    Swal.fire({
                        icon: "success",
                        title: "Berhasil!",
                        text: res.message,
                        timer: 1200,
                        showConfirmButton: false
                    });

                    setTimeout(() => {
                        location.reload();
                    }, 1200);
                },

                error: function(err) {
                    if (err.status === 422) {
                        let errors = err.responseJSON.errors;

                        if (errors.title_tag)
                            $("#edit_error_title_tag").text(errors.title_tag[0]);

                        if (errors.main_title)
                            $("#edit_error_main_title").text(errors.main_title[0]);

                        if (errors.intro_text)
                            $("#edit_error_intro_text").text(errors.intro_text[0]);

                    } else {
                        Swal.fire({
                            icon: "error",
                            title: "Gagal!",
                            text: "Terjadi kesalahan server."
                        });
                    }
                }

            });

        });


        $(".btn-delete").click(function() {

            let id = $(this).data("id");

            Swal.fire({
                title: "Yakin hapus?",
                text: "Data ini tidak bisa dikembalikan!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "Ya, hapus!",
                cancelButtonText: "Batal",
            }).then((res) => {
                if (res.isConfirmed) {

                    $.ajax({
                        url: "/admin/testimoni/header/" + id,
                        method: "DELETE",
                        data: {
                            _token: "<?php echo e(csrf_token()); ?>"
                        },

                        success: function() {
                            toastr.success("Data berhasil dihapus!");
                            setTimeout(() => location.reload(), 700);
                        }
                    });
                }
            });

        });

        $(document).on('change', '.toggle-aktif', function() {
            let id = $(this).data('id');
            let status = $(this).is(':checked') ? 1 : 0;

            $.ajax({
                url: "<?php echo e(route('testimoni.toggleAktif')); ?>",
                type: "POST",
                data: {
                    id: id,
                    flag_aktif: status,
                    _token: "<?php echo e(csrf_token()); ?>"
                },
                success: function(res) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil',
                        text: res.message,
                        timer: 1200,
                        showConfirmButton: false
                    }).then(() => {
                        location.reload();
                    });
                },
                error: function() {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal',
                        text: 'Terjadi kesalahan.',
                        timer: 1200,
                        showConfirmButton: false
                    });
                }
            });
        });

    });
</script>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/testimoni/script.blade.php ENDPATH**/ ?>