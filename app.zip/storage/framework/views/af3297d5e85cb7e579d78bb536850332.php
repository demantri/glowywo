<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">Tambah Layanan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                
                <div class="mb-3">
                    <label class="form-label">Service Icon</label>
                    <input type="text" id="add_service_icon" class="form-control"
                        placeholder="Contoh: fa-solid fa-user">

                    <small class="text-muted">
                        Silahkan lihat icon lengkap nya <a href="https://icons.getbootstrap.com/" target="_blank">disini</a>
                    </small>

                    <small class="text-danger" id="error_service_icon"></small>
                </div>

                
                <div class="mb-3">
                    <label class="form-label">Service Title</label>
                    <input type="text" id="add_service_title" class="form-control">
                    <small class="text-danger" id="error_service_title"></small>
                </div>

                
                <div class="mb-3">
                    <label class="form-label">Service Description</label>
                    <textarea id="add_service_desc" cols="10" rows="5" class="form-control"></textarea>
                    <small class="text-danger" id="error_service_desc"></small>
                </div>

                
                <div class="mb-3">
                    <label class="form-label">Service Link Text</label>
                    <input type="text" id="add_service_link_text" class="form-control"
                        placeholder="Contoh: Learn More">
                    <small class="text-danger" id="error_service_link_text"></small>
                </div>

                
                <div class="mb-3">
                    <label class="form-label">Service Order</label>
                    <input type="number" id="add_service_order" class="form-control" min="1" value="1">
                    <small class="text-danger" id="error_service_order"></small>
                </div>

                
                <div class="mb-3">
                    <label class="form-label d-block">Flag Aktif</label>

                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="add_flag_aktif" value="1">
                        <label class="form-check-label" for="add_flag_aktif">Aktifkan</label>
                    </div>

                    <small class="text-muted">Default: Tidak aktif (0)</small>
                </div>

            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button class="btn btn-primary" id="btnSave">Simpan</button>
            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/layanan/add.blade.php ENDPATH**/ ?>