<footer class="bg-dark text-white py-4 mt-5">
    <div class="container text-center">
        <p class="mb-1">© <?php echo e(date('Y')); ?> YourBrand. All Rights Reserved.</p>
        <small>Wedding & Event Organizer</small>
    </div>
</footer>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/website/components/footer.blade.php ENDPATH**/ ?>