<section id="contact" class="contact section light-background">
    <!-- Section Title -->
    <div class="container section-title" data-aos="fade-up">
        <span class="subtitle"><?php echo e($kontak->title_tag); ?></span>
        <h2><?php echo e($kontak->main_title); ?></h2>
        <p>
            <?php echo e($kontak->intro_text); ?>

        </p>
    </div><!-- End Section Title -->

    <div class="container">
        <div class="row gy-4">
            <div class="col-lg-5">

                <div class="info-item">
                    <div class="info-icon">
                        <i class="bi bi-chat-dots"></i>
                    </div>
                    <div class="info-content">
                        <h4><?php echo e($kontak->main_title2); ?></h4>
                        <p>
                            <?php echo e($kontak->intro_text2); ?>

                        </p>
                    </div>
                </div>

                <div class="contact-details">

                    <div class="detail-item">
                        <div class="detail-icon">
                            <i class="bi bi-envelope-open"></i>
                        </div>
                        <div class="detail-content">
                            <span class="detail-label">Email Kami</span>
                            <span class="detail-value"><?php echo e($profilePerusahaan->email_kantor); ?></span>
                        </div>
                    </div>

                    <div class="detail-item">
                        <div class="detail-icon">
                            <i class="bi bi-telephone-outbound"></i>
                        </div>
                        <div class="detail-content">
                            <span class="detail-label">Telepon Kami</span>
                            <span class="detail-value"><?php echo e($profilePerusahaan->no_telp_kantor); ?></span>
                        </div>
                    </div>

                    <div class="detail-item">
                        <div class="detail-icon">
                            <i class="bi bi-geo-alt-fill"></i>
                        </div>
                        <div class="detail-content">
                            <span class="detail-label">Kunjungi Kami</span>
                            <span class="detail-value"><?php echo e($profilePerusahaan->alamat_kantor); ?></span>
                        </div>
                    </div>

                </div>

            </div>

            <div class="col-lg-7">
                <div class="form-wrapper">
                    <div class="form-header">
                        <h3>Kirimkan Pesan kepada Kami</h3>
                    </div>

                    <form action="forms/contact.php" method="post" class="php-email-form">

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Nama Lengkap</label>
                                    <input type="text" name="name" required="">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Alamat Email</label>
                                    <input type="email" name="email" required="">
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Subjek</label>
                            <input type="text" name="subject" required="" placeholder="Tanya Detail Layanan WO">
                        </div>

                        <div class="form-group">
                            <label for="projectMessage">Pesan</label>
                            <textarea name="message" id="projectMessage" rows="5" required="" placeholder="Tolong sertakan detail acara Anda: tanggal, jenis acara (Wedding/EO), dan jumlah tamu perkiraan."></textarea>
                        </div>

                        <div class="my-3">
                            <div class="loading">Loading</div>
                            <div class="error-message"></div>
                            <div class="sent-message">Your message has been sent. Thank you!</div>
                        </div>

                        <button type="submit" class="submit-btn">
                            <span>Kirim Pesan</span>
                            <i class="bi bi-arrow-right"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/website/contact.blade.php ENDPATH**/ ?>