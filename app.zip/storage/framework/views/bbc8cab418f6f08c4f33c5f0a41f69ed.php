<section id="hero" class="hero section light-background">

    <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="hero-content">
                    <h1 data-aos="fade-up" data-aos-delay="200">
                        <?php echo e($beranda->hero_headline); ?>

                    </h1>
                    <p data-aos="fade-up" data-aos-delay="300">
                        <?php echo e($beranda->hero_subtext); ?>

                    </p>
                    <div class="hero-cta" data-aos="fade-up" data-aos-delay="400">
                        <a href="#about" class="btn-primary"><?php echo e($beranda->btn_primary_text); ?></a>
                        <a href="<?php echo e(asset('website/assets/video/sample.mp4')); ?>" class="btn-secondary glightbox">
                            <i class="bi bi-play-circle"></i>
                            <?php echo e($beranda->btn_secondary_text); ?>

                        </a>
                    </div>
                    <div class="hero-stats" data-aos="fade-up" data-aos-delay="500">
                        <div class="stat-item">
                            <div class="stat-number"><?php echo e($beranda->stat_1_value); ?></div>
                            <div class="stat-label"><?php echo e($beranda->stat_1_label); ?></div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number"><?php echo e($beranda->stat_2_value); ?></div>
                            <div class="stat-label"><?php echo e($beranda->stat_2_label); ?></div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number"><?php echo e($beranda->stat_3_value); ?></div>
                            <div class="stat-label"><?php echo e($beranda->stat_3_label); ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="hero-image" data-aos="fade-left" data-aos-delay="300">
                    <img src="<?php echo e(asset('storage/' . $beranda->image)); ?>" alt="Event Organizer"
                        class="img-fluid">
                </div>
            </div>
        </div>

    </div>

</section>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/website/hero.blade.php ENDPATH**/ ?>