<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">Edit Footer</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <input type="hidden" id="edit_footer_id">

                <div class="mb-3">
                    <label class="form-label">Company Description</label>
                    <textarea id="edit_company_desc" class="form-control" rows="4"></textarea>
                    <small class="text-danger" id="edit_error_company_desc"></small>
                </div>

                <div class="mb-3">
                    <label class="form-label">Copyright Year</label>
                    <input type="text" id="edit_copyright_year"
                        class="form-control">
                    <small class="text-danger" id="edit_error_copyright_year"></small>
                </div>

                <div class="mb-3">
                    <label class="form-label">Instagram</label>
                    <input type="text" id="edit_social_instagram" class="form-control">
                </div>

                <div class="mb-3">
                    <label class="form-label">Facebook</label>
                    <input type="text" id="edit_social_facebook" class="form-control">
                </div>

                <div class="mb-3">
                    <label class="form-label">LinkedIn</label>
                    <input type="text" id="edit_social_linkedin" class="form-control">
                </div>

                <div class="mb-3">
                    <label class="form-label d-block">Flag Aktif</label>
                    <div class="form-check form-switch">
                        <input type="checkbox" id="edit_flag_aktif" class="form-check-input">
                        <label class="form-check-label" for="edit_flag_aktif">Aktifkan</label>
                    </div>
                </div>

            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button class="btn btn-primary" id="btnUpdate">Update</button>
            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/footer/edit.blade.php ENDPATH**/ ?>