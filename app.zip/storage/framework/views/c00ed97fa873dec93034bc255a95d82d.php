

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Layanan</h5>
                    <?php if(!$dataAktif): ?>
                        <button class="btn btn-primary" id="btnAdd">Tambah Data</button>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <table class="table table-bordered" id="table">
                        <thead class="table-light">
                            <tr>
                                <th width="2%">#</th>
                                <th>Company Desc</th>
                                <th>Copyright Year</th>
                                <th>Social Instagram</th>
                                <th>Social Facebook</th>
                                <th>Social LinkedIn</th>
                                <th>Flag Aktif</th>
                                <th width="15%">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->company_desc); ?></td>
                                    <td><?php echo e($item->copyright_year); ?></td>
                                    <td><?php echo e($item->social_instagram); ?></td>
                                    <td><?php echo e($item->social_facebook); ?></td>
                                    <td><?php echo e($item->social_linkedin); ?></td>
                                    <td class="text-center">
                                        <div class="d-flex justify-content-center">
                                            <div class="form-check form-switch m-0">
                                                <input class="form-check-input toggle-aktif" type="checkbox"
                                                    data-id="<?php echo e($item->footer_id); ?>"
                                                    <?php echo e($item->flag_aktif == 1 ? 'checked' : ''); ?>>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <button class="btn btn-warning btn-sm btn-edit" 
                                            data-id="<?php echo e($item->footer_id); ?>"
                                            data-desc="<?php echo e($item->company_desc); ?>"
                                            data-year="<?php echo e($item->copyright_year); ?>"
                                            data-ig="<?php echo e($item->social_instagram); ?>"
                                            data-fb="<?php echo e($item->social_facebook); ?>"
                                            data-in="<?php echo e($item->social_linkedin); ?>"
                                            data-aktif="<?php echo e($item->flag_aktif); ?>"
                                        >
                                            Edit
                                        </button>
                                        <button class="btn btn-danger btn-sm btn-delete" data-id="<?php echo e($item->footer_id); ?>">
                                            Hapus
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin.footer.add', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.footer.edit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo $__env->make('admin.footer.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/footer/index.blade.php ENDPATH**/ ?>