<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">Tambah Footer</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <div class="mb-3">
                    <label class="form-label">Company Description</label>
                    <textarea id="add_company_desc" class="form-control" rows="4"></textarea>
                    <small class="text-danger" id="error_company_desc"></small>
                </div>

                <div class="mb-3">
                    <label class="form-label">Copyright Year</label>
                    <input type="text" id="add_copyright_year"
                        class="form-control" placeholder="2024">
                    <small class="text-danger" id="error_copyright_year"></small>
                </div>

                <div class="mb-3">
                    <label class="form-label">Instagram</label>
                    <input type="text" id="add_social_instagram" class="form-control" placeholder="https://instagram.com/..">
                </div>

                <div class="mb-3">
                    <label class="form-label">Facebook</label>
                    <input type="text" id="add_social_facebook" class="form-control" placeholder="https://facebook.com/..">
                </div>

                <div class="mb-3">
                    <label class="form-label">LinkedIn</label>
                    <input type="text" id="add_social_linkedin" class="form-control" placeholder="https://linkedin.com/..">
                </div>

                <div class="mb-3">
                    <label class="form-label d-block">Flag Aktif</label>

                    <div class="form-check form-switch">
                        <input type="checkbox" class="form-check-input" id="add_flag_aktif">
                        <label for="add_flag_aktif" class="form-check-label">Aktifkan</label>
                    </div>
                </div>

            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button class="btn btn-primary" id="btnSave">Simpan</button>
            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/footer/add.blade.php ENDPATH**/ ?>