<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">Edit Header Layanan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <input type="hidden" id="edit_id">

                <div class="mb-3">
                    <label class="form-label">Title Tag</label>
                    <input type="text" id="edit_title_tag" class="form-control">
                    <small class="text-danger" id="edit_error_title_tag"></small>
                </div>

                <div class="mb-3">
                    <label class="form-label">Main Title</label>
                    <input type="text" id="edit_main_title" class="form-control">
                    <small class="text-danger" id="edit_error_main_title"></small>
                </div>

                <div class="mb-3">
                    <label class="form-label">Intro Text</label>
                    <textarea id="edit_intro_text" cols="10" rows="5" class="form-control"></textarea>
                    <small class="text-danger" id="edit_error_intro_text"></small>
                </div>

                <div class="mb-3">
                    <label class="form-label d-block">Flag Aktif</label>

                    <div class="form-check form-switch">
                        <input 
                            class="form-check-input"
                            type="checkbox"
                            id="edit_flag_aktif"
                            value="1"
                        >
                        <label class="form-check-label" for="edit_flag_aktif">Aktifkan</label>
                    </div>

                </div>

            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button class="btn btn-primary" id="btnUpdate">Update</button>
            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/testimoni/header/edit.blade.php ENDPATH**/ ?>