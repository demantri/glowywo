

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Management Users</h5>

                    <button class="btn btn-primary" id="btnAdd">Tambah Data</button>
                </div>
                <div class="card-body">
                    <table class="table table-bordered" id="userTable">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Nama</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Role</th>
                                
                                <th>Sosial Media</th>
                                <th width="20%">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="row_<?php echo e($user->id); ?>">
                                    <td><?php echo e($i + 1); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->username ?? '-'); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->role->name); ?></td>
                                    
                                    <td><?php echo e($user->social_media ?? '-'); ?></td>

                                    <td class="text-center">
                                        <button class="btn btn-warning btn-sm btn-edit" data-id="<?php echo e($user->id); ?>"
                                            data-name="<?php echo e($user->name); ?>" data-username="<?php echo e($user->username); ?>"
                                            data-email="<?php echo e($user->email); ?>" data-role="<?php echo e($user->role_id); ?>"
                                            data-social="<?php echo e($user->social_media); ?>">
                                            Edit
                                        </button>


                                        <button class="btn btn-danger btn-sm btn-delete" data-id="<?php echo e($user->id); ?>">
                                            Hapus
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin.user.add', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.user.edit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo $__env->make('admin.user.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/user/index.blade.php ENDPATH**/ ?>