<section id="testimonials" class="testimonials section">

    <!-- Section Title -->
    <div class="container section-title" data-aos="fade-up">
        <span class="subtitle"><?php echo e($headerTesti->title_tag); ?></span>
        <h2><?php echo e($headerTesti->main_title); ?></h2>
        <p>
            <?php echo e($headerTesti->intro_text); ?>

        </p>
    </div><!-- End Section Title -->

    <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="testimonial-slider swiper init-swiper">
            <script type="application/json" class="swiper-config">
            {
              "loop": true,
              "speed": 600,
              "autoplay": {
                "delay": 4000
              },
              "slidesPerView": 1,
              "spaceBetween": 30,
              "navigation": {
                "nextEl": ".swiper-button-next",
                "prevEl": ".swiper-button-prev"
              },
              "breakpoints": {
                "768": {
                  "slidesPerView": 2
                },
                "1200": {
                  "slidesPerView": 3
                }
              }
            }
          </script>

            <div class="swiper-wrapper">
                <?php $__currentLoopData = $testi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="swiper-slide">
                        <div class="testimonial-item" data-aos="zoom-in" data-aos-delay="200">
                            <div class="testimonial-header">
                                <img src="<?php echo e(asset('website/assets/img/person/default.webp')); ?>" alt="Client"
                                    class="img-fluid" loading="lazy">
                                <div class="rating">
                                    <?php for($i = 0; $i < $item->rating_star; $i++): ?>
                                    <i class="bi bi-star-fill"></i>
                                    <?php endfor; ?>
                                </div>
                            </div>
                            <div class="testimonial-body" style="height: 150px !important; margin-bottom: 2rem;">
                                <p>
                                    <?php echo e(Str::limit($item->ulasan_text, 300, '...')); ?>

                                </p>
                            </div>
                            <div class="testimonial-footer">
                                <h5><?php echo e($item->nama_klien); ?></h5>
                                <div class="quote-icon">
                                    <i class="bi bi-chat-quote-fill"></i>
                                </div>
                            </div>
                        </div>
                    </div><!-- End Testimonial Slide -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="swiper-navigation">
                <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div>
            </div>

        </div>

    </div>

</section>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/website/testimonials.blade.php ENDPATH**/ ?>