<script>
    $(function() {

        $("#table").DataTable();

        $("#btnAdd").click(function() {
            $("#addModal").modal('show');
        });

        $("#btnSave").click(function() {

            $.ajax({
                url: "<?php echo e(route('footer.store')); ?>",
                method: "POST",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    company_desc: $("#add_company_desc").val(),
                    copyright_year: $("#add_copyright_year").val(),
                    social_instagram: $("#add_social_instagram").val(),
                    social_facebook: $("#add_social_facebook").val(),
                    social_linkedin: $("#add_social_linkedin").val(),
                    flag_aktif: $("#add_flag_aktif").is(":checked") ? 1 : 0,
                },

                success: function(res) {
                    $("#addModal").modal("hide");
                    $(".modal-backdrop").remove();
                    Swal.fire({
                        icon: "success",
                        title: "Berhasil!",
                        text: res.message,
                        timer: 1000,
                        showConfirmButton: false
                    }).then(() => {
                        location.reload();
                    });
                },

                error(xhr) {
                    let e = xhr.responseJSON.errors;
                    $("#error_company_desc").text(e?.company_desc ?? "");
                    $("#error_copyright_year").text(e?.copyright_year ?? "");
                }
            });
        });

        $(".btn-edit").click(function() {

            $("#edit_footer_id").val($(this).data("id"));
            $("#edit_company_desc").val($(this).data("desc"));
            $("#edit_copyright_year").val($(this).data("year"));
            $("#edit_social_instagram").val($(this).data("ig"));
            $("#edit_social_facebook").val($(this).data("fb"));
            $("#edit_social_linkedin").val($(this).data("in"));
            $("#edit_flag_aktif").prop("checked", $(this).data("aktif") == 1);

            $("#editModal").modal("show");
        });

        $("#btnUpdate").click(function() {

            let id = $("#edit_footer_id").val();

            $.ajax({
                url: "/admin/footer/" + id,
                method: "POST",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    _method: "PUT",

                    company_desc: $("#edit_company_desc").val(),
                    copyright_year: $("#edit_copyright_year").val(),
                    social_instagram: $("#edit_social_instagram").val(),
                    social_facebook: $("#edit_social_facebook").val(),
                    social_linkedin: $("#edit_social_linkedin").val(),
                    flag_aktif: $("#edit_flag_aktif").is(":checked") ? 1 : 0
                },

                success(res) {
                    $("#editModal").modal("hide");
                    $(".modal-backdrop").remove();
                    Swal.fire({
                        icon: "success",
                        title: "Berhasil!",
                        text: res.message,
                        timer: 1000,
                        showConfirmButton: false
                    }).then(() => {
                        location.reload();
                    });
                },
            });
        });

        $(".btn-delete").click(function() {

            let id = $(this).data("id");

            Swal.fire({
                title: "Hapus Footer?",
                text: "Data ini tidak bisa dikembalikan!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "Ya, hapus",
                cancelButtonText: "Batal"
            }).then((r) => {

                if (r.isConfirmed) {
                    $.ajax({
                        url: "/admin/footer/" + id,
                        method: "DELETE",
                        data: {
                            _token: "<?php echo e(csrf_token()); ?>"
                        },

                        success() {
                            Swal.fire("Berhasil!", "Data footer dihapus.", "success");
                            setTimeout(() => location.reload(), 800);
                        }
                    });
                }
            });

        });

        $(document).on('change', '.toggle-aktif', function() {
            let id = $(this).data('id');
            let status = $(this).is(':checked') ? 1 : 0;

            $.ajax({
                url: "<?php echo e(route('footer.toggle')); ?>",
                type: "POST",
                data: {
                    id: id,
                    flag_aktif: status,
                    _token: "<?php echo e(csrf_token()); ?>"
                },
                success: function(res) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil',
                        text: res.message,
                        timer: 1200,
                        showConfirmButton: false
                    }).then(() => {
                        location.reload();
                    });
                },
                error: function() {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal',
                        text: 'Terjadi kesalahan.',
                        timer: 1200,
                        showConfirmButton: false
                    });
                }
            });
        });

    });
</script>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/footer/script.blade.php ENDPATH**/ ?>