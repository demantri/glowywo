

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">

            <div class="card">

                <div class="card-header d-flex justify-content-between">
                    <h5 class="mb-0">Beranda</h5>

                    <?php if(!$data): ?>
                        <button class="btn btn-primary" id="btnAdd">Tambah Data</button>
                    <?php endif; ?>
                </div>

                <div class="card-body">

                    <?php if($data): ?>
                        <table class="table table-bordered">

                            <tr>
                                <th width="25%">Hero Headline</th>
                                <td><?php echo e($data->hero_headline); ?></td>
                            </tr>

                            <tr>
                                <th>Hero Subtext</th>
                                <td><?php echo e($data->hero_subtext); ?></td>
                            </tr>

                            <tr>
                                <th>Primary Button</th>
                                <td><?php echo e($data->btn_primary_text); ?></td>
                            </tr>

                            <tr>
                                <th>Secondary Button</th>
                                <td><?php echo e($data->btn_secondary_text); ?></td>
                            </tr>

                            <tr>
                                <th colspan="2" class="table-secondary text-center">Statistics</th>
                            </tr>

                            <tr>
                                <th>Stat 1</th>
                                <td><strong><?php echo e($data->stat_1_value); ?></strong> — <?php echo e($data->stat_1_label); ?></td>
                            </tr>

                            <tr>
                                <th>Stat 2</th>
                                <td><strong><?php echo e($data->stat_2_value); ?></strong> — <?php echo e($data->stat_2_label); ?></td>
                            </tr>

                            <tr>
                                <th>Stat 3</th>
                                <td><strong><?php echo e($data->stat_3_value); ?></strong> — <?php echo e($data->stat_3_label); ?></td>
                            </tr>

                            <tr>
                                <th>Gambar</th>
                                <td>
                                    <?php if($data->image): ?>
                                        <img src="<?php echo e(asset('storage/' . $data->image)); ?>" width="200"
                                            class="rounded shadow">
                                    <?php else: ?>
                                        <small class="text-muted">Gambar belum diupload</small>
                                    <?php endif; ?>
                                </td>
                            </tr>

                            <tr>
                                <td colspan="2" class="text-center">

                                    <button class="btn btn-warning btn-edit" data-id="<?php echo e($data->home_id); ?>"
                                        data-hero_headline="<?php echo e($data->hero_headline); ?>"
                                        data-hero_subtext="<?php echo e($data->hero_subtext); ?>"
                                        data-btn_primary_text="<?php echo e($data->btn_primary_text); ?>"
                                        data-btn_secondary_text="<?php echo e($data->btn_secondary_text); ?>"
                                        data-stat_1_value="<?php echo e($data->stat_1_value); ?>"
                                        data-stat_1_label="<?php echo e($data->stat_1_label); ?>"
                                        data-stat_2_value="<?php echo e($data->stat_2_value); ?>"
                                        data-stat_2_label="<?php echo e($data->stat_2_label); ?>"
                                        data-stat_3_value="<?php echo e($data->stat_3_value); ?>"
                                        data-stat_3_label="<?php echo e($data->stat_3_label); ?>">Edit</button>

                                    <button class="btn btn-danger btn-delete" data-id="<?php echo e($data->home_id); ?>">
                                        Hapus
                                    </button>

                                </td>
                            </tr>

                        </table>
                    <?php else: ?>
                        <p class="text-muted text-center">Belum ada data</p>
                    <?php endif; ?>

                </div>

            </div>

        </div>
    </div>

    <?php echo $__env->make('admin.beranda.add', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.beranda.edit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo $__env->make('admin.beranda.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/beranda/index.blade.php ENDPATH**/ ?>