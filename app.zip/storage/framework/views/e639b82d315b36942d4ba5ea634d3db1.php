<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">Tambah Data Beranda</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <div class="row">

                    
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Hero Headline *</label>
                        <input type="text" id="add_hero_headline" class="form-control">
                        <small class="text-danger" id="error_add_hero_headline"></small>
                    </div>

                    
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Hero Subtext *</label>
                        <textarea id="add_hero_subtext" rows="3" class="form-control"></textarea>
                        <small class="text-danger" id="error_add_hero_subtext"></small>
                    </div>

                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Primary Button *</label>
                        <input type="text" id="add_btn_primary_text" class="form-control">
                        <small class="text-danger" id="error_add_btn_primary_text"></small>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Secondary Button *</label>
                        <input type="text" id="add_btn_secondary_text" class="form-control">
                        <small class="text-danger" id="error_add_btn_secondary_text"></small>
                    </div>

                    
                    <h6 class="mt-3">Statistik</h6>

                    <div class="col-md-3 mb-3">
                        <label>Stat 1 Value *</label>
                        <input type="text" id="add_stat_1_value" class="form-control">
                    </div>
                    <div class="col-md-9 mb-3">
                        <label>Stat 1 Label *</label>
                        <input type="text" id="add_stat_1_label" class="form-control">
                    </div>

                    <div class="col-md-3 mb-3">
                        <label>Stat 2 Value *</label>
                        <input type="text" id="add_stat_2_value" class="form-control">
                    </div>
                    <div class="col-md-9 mb-3">
                        <label>Stat 2 Label *</label>
                        <input type="text" id="add_stat_2_label" class="form-control">
                    </div>

                    <div class="col-md-3 mb-3">
                        <label>Stat 3 Value *</label>
                        <input type="text" id="add_stat_3_value" class="form-control">
                    </div>
                    <div class="col-md-9 mb-3">
                        <label>Stat 3 Label *</label>
                        <input type="text" id="add_stat_3_label" class="form-control">
                    </div>

                    
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Gambar Hero</label>
                        <input type="file" id="add_image" class="form-control">
                        <img id="preview_add_image" class="img-fluid mt-2" style="max-height:150px; display:none;">
                    </div>

                </div>
            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button class="btn btn-primary" id="btnSave">Simpan</button>
            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/admin/beranda/add.blade.php ENDPATH**/ ?>