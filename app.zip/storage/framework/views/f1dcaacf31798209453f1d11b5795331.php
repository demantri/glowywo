<section id="team" class="team section">

    <!-- Section Title -->
    <div class="container section-title" data-aos="fade-up">
        <span class="subtitle">Team</span>
        <h2>Meet Our Team</h2>
        <p>Necessitatibus eius consequatur ex aliquid fuga eum quidem sint consectetur velit. Sed ut
            perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium totam rem
            aperiam</p>
    </div><!-- End Section Title -->

    <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row gy-5">

            <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="200">
                <div class="team-member">
                    <div class="member-img">
                        <img src="<?php echo e(asset('website/assets/img/person/person-f-8.webp')); ?>" class="img-fluid" alt="Sarah Johnson"
                            loading="lazy">
                    </div>
                    <div class="member-info">
                        <h4>Sarah Johnson</h4>
                        <span>Chief Executive Officer</span>
                        <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis
                            egestas vestibulum tortor quam.</p>
                        <div class="social">
                            <a href="#"><i class="bi bi-twitter-x"></i></a>
                            <a href="#"><i class="bi bi-linkedin"></i></a>
                            <a href="#"><i class="bi bi-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div><!-- End Team Member -->

            <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="250">
                <div class="team-member">
                    <div class="member-img">
                        <img src="<?php echo e(asset('website/assets/img/person/person-m-12.webp')); ?>" class="img-fluid" alt="Michael Chen"
                            loading="lazy">
                    </div>
                    <div class="member-info">
                        <h4>Michael Chen</h4>
                        <span>Chief Technology Officer</span>
                        <p>Mauris blandit aliquet elit eget tincidunt nibh pulvinar rutrum tellus ac blandit
                            elit eget tincidunt mauris.</p>
                        <div class="social">
                            <a href="#"><i class="bi bi-twitter-x"></i></a>
                            <a href="#"><i class="bi bi-linkedin"></i></a>
                            <a href="#"><i class="bi bi-github"></i></a>
                        </div>
                    </div>
                </div>
            </div><!-- End Team Member -->

            <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="300">
                <div class="team-member">
                    <div class="member-img">
                        <img src="<?php echo e(asset('website/assets/img/person/person-f-3.webp')); ?>" class="img-fluid" alt="Emily Rodriguez"
                            loading="lazy">
                    </div>
                    <div class="member-info">
                        <h4>Emily Rodriguez</h4>
                        <span>Creative Director</span>
                        <p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia
                            curae donec velit neque auctor.</p>
                        <div class="social">
                            <a href="#"><i class="bi bi-twitter-x"></i></a>
                            <a href="#"><i class="bi bi-linkedin"></i></a>
                            <a href="#"><i class="bi bi-dribbble"></i></a>
                        </div>
                    </div>
                </div>
            </div><!-- End Team Member -->

            <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="350">
                <div class="team-member">
                    <div class="member-img">
                        <img src="<?php echo e(asset('website/assets/img/person/person-m-7.webp')); ?>" class="img-fluid" alt="David Thompson"
                            loading="lazy">
                    </div>
                    <div class="member-info">
                        <h4>David Thompson</h4>
                        <span>Head of Operations</span>
                        <p>Curabitur arcu erat accumsan id imperdiet et porttitor at sem nulla facilisi mauris
                            sit amet massa vitae tortor.</p>
                        <div class="social">
                            <a href="#"><i class="bi bi-twitter-x"></i></a>
                            <a href="#"><i class="bi bi-linkedin"></i></a>
                            <a href="#"><i class="bi bi-facebook"></i></a>
                        </div>
                    </div>
                </div>
            </div><!-- End Team Member -->

        </div>

    </div>

</section>
<?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/website/team.blade.php ENDPATH**/ ?>