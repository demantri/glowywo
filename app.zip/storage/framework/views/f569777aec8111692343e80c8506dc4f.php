

<?php $__env->startSection('content'); ?>
    <section class="container py-5">
        <div class="row align-items-center" data-aos="fade-up">
            <div class="col-md-6">
                <h2 class="fw-bold mb-3">About Us</h2>
                <p class="text-muted">
                    We are a professional Wedding and Event Organizer dedicated to creating
                    unforgettable moments for our clients. With years of experience,
                    our team specializes in transforming your dream event into reality.
                </p>
                <p class="text-muted">
                    From weddings, anniversaries, corporate events, to private celebrations—
                    we handle everything from concept, planning, decoration, to execution.
                </p>
            </div>

            <div class="col-md-6 text-center">
                <img src="/images/about.jpg" class="img-fluid rounded shadow" alt="About">
            </div>
        </div>

        <div class="row text-center mt-5">
            <h3 class="fw-bold mb-4">Why Choose Us?</h3>

            <div class="col-md-3" data-aos="fade-up">
                <h1>✨</h1>
                <p>Professional Team</p>
            </div>
            <div class="col-md-3" data-aos="fade-up">
                <h1>💡</h1>
                <p>Creative Concepts</p>
            </div>
            <div class="col-md-3" data-aos="fade-up">
                <h1>📅</h1>
                <p>Detail Planning</p>
            </div>
            <div class="col-md-3" data-aos="fade-up">
                <h1>⭐</h1>
                <p>Premium Experience</p>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/website/pages/about.blade.php ENDPATH**/ ?>