

<?php $__env->startSection('content'); ?>
    <section class="container py-5">
        <div class="row align-items-center" data-aos="fade-up">
            <div class="col-md-6">
                <h2 class="fw-bold mb-3">Event Organizer</h2>
                <p class="text-muted">
                    We manage corporate events, gatherings, product launches, birthday parties,
                    and all types of creative events with professional execution.
                </p>

                <h5 class="fw-bold mt-4">Event Types:</h5>
                <ul>
                    <li>🏢 Corporate Events</li>
                    <li>🎉 Birthday Celebrations</li>
                    <li>🚀 Product Launching</li>
                    <li>🎤 Gathering Events</li>
                </ul>
            </div>

            <div class="col-md-6 text-center">
                <img src="/images/event.jpg" class="img-fluid rounded shadow">
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/website/pages/event.blade.php ENDPATH**/ ?>