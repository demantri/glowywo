

<?php $__env->startSection('content'); ?>
    <section class="container py-5">
        <h2 class="fw-bold text-center mb-5">Our Portfolio</h2>

        <div class="row g-4">

            <!-- Example Portfolio Item -->
            <?php for($i = 1; $i <= 6; $i++): ?>
                <div class="col-md-4" data-aos="fade-up">
                    <div class="card shadow-sm">
                        <img src="/images/portfolio<?php echo e($i); ?>.jpg" class="card-img-top"
                            alt="Portfolio <?php echo e($i); ?>">
                        <div class="card-body text-center">
                            <h5 class="fw-bold">Project <?php echo e($i); ?></h5>
                            <button class="btn btn-outline-dark mt-2" data-bs-toggle="modal"
                                data-bs-target="#modal<?php echo e($i); ?>">
                                View Detail
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Modal Detail -->
                <div class="modal fade" id="modal<?php echo e($i); ?>" tabindex="-1">
                    <div class="modal-dialog modal-lg modal-dialog-centered">
                        <div class="modal-content">
                            <img src="/images/portfolio<?php echo e($i); ?>.jpg" class="w-100 rounded-top">

                            <div class="modal-body">
                                <h4 class="fw-bold">Project <?php echo e($i); ?></h4>
                                <p class="text-muted">
                                    Full detailed description of the project goes here. Includes decoration style, event
                                    type,
                                    number of guests, special requests, etc.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endfor; ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\latihan\freelance\glowyeo-cms\resources\views/website/pages/portfolio.blade.php ENDPATH**/ ?>